package com.tuition.management.config;

import com.tuition.management.entity.*;
import com.tuition.management.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository; // 🔥 thêm cái này

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private InvoiceRepository invoiceRepository;

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {

        // ================== USERS + ROLES ==================
        if (userRepository.count() == 0) {

            // Tạo hoặc lấy role ADMIN
            Role adminRole = roleRepository.findByName("ADMIN")
                    .orElseGet(() -> {
                        Role r = new Role();
                        r.setName("ADMIN");
                        return roleRepository.save(r);
                    });

            // Tạo hoặc lấy role STAFF
            Role staffRole = roleRepository.findByName("STAFF")
                    .orElseGet(() -> {
                        Role r = new Role();
                        r.setName("STAFF");
                        return roleRepository.save(r);
                    });

            // ADMIN
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("123456"));
            admin.setFullName("Administrator");
            admin.setEmail("admin@tuition.com");
            admin.setPhone("0123456789");
            admin.setEnabled(true);
            admin.setRoles(Arrays.asList(adminRole));
            userRepository.save(admin);

            // STAFF
            User staff = new User();
            staff.setUsername("staff");
            staff.setPassword(passwordEncoder.encode("123456"));
            staff.setFullName("Nhân viên");
            staff.setEmail("staff@tuition.com");
            staff.setPhone("0987654321");
            staff.setEnabled(true);
            staff.setRoles(Arrays.asList(staffRole));
            userRepository.save(staff);
        }

        // ================== CUSTOMERS ==================
        if (customerRepository.count() == 0) {

            Customer customer1 = new Customer();
            customer1.setFullName("Nguyễn Văn A");
            customer1.setBirthDate(LocalDate.of(2000, 1, 15));
            customer1.setGender("MALE");
            customer1.setEmail("nguyenvana@email.com");
            customer1.setPhone("0912345678");
            customer1.setAddress("Hà Nội");
            customer1.setCourse("Lập trình Java Fullstack");
            customer1.setStudentCode("SV2024001");
            customer1.setStatus("ACTIVE");
            customerRepository.save(customer1);

            Customer customer2 = new Customer();
            customer2.setFullName("Trần Thị B");
            customer2.setBirthDate(LocalDate.of(2001, 5, 20));
            customer2.setGender("FEMALE");
            customer2.setEmail("tranthib@email.com");
            customer2.setPhone("0923456789");
            customer2.setAddress("Hồ Chí Minh");
            customer2.setCourse("Python cho Data Science");
            customer2.setStudentCode("SV2024002");
            customer2.setStatus("ACTIVE");
            customerRepository.save(customer2);

            // ================== INVOICES ==================
            Invoice invoice1 = new Invoice();
            invoice1.setInvoiceNumber("INV2024001");
            invoice1.setCustomer(customer1);
            invoice1.setDescription("Học phí tháng 1/2024 - Khóa Java");
            invoice1.setAmount(new BigDecimal("5000000"));
            invoice1.setDiscount(new BigDecimal("500000"));
            invoice1.setTax(new BigDecimal("10"));
            invoice1.setIssueDate(LocalDate.now());
            invoice1.setDueDate(LocalDate.now().plusDays(30));
            invoice1.setStatus("PENDING");
            invoiceRepository.save(invoice1);

            Invoice invoice2 = new Invoice();
            invoice2.setInvoiceNumber("INV2024002");
            invoice2.setCustomer(customer2);
            invoice2.setDescription("Học phí tháng 1/2024 - Khóa Python");
            invoice2.setAmount(new BigDecimal("6000000"));
            invoice2.setIssueDate(LocalDate.now());
            invoice2.setDueDate(LocalDate.now().plusDays(30));
            invoice2.setStatus("PAID");
            invoiceRepository.save(invoice2);

            // ================== PAYMENTS ==================
            Payment payment1 = new Payment();
            payment1.setPaymentNumber("PM2024001");
            payment1.setInvoice(invoice2);
            payment1.setAmount(new BigDecimal("6000000"));
            payment1.setPaymentDate(LocalDate.now());
            payment1.setPaymentMethod("BANK_TRANSFER");
            payment1.setStatus("COMPLETED");
            payment1.setTransactionId("TRX123456");
            paymentRepository.save(payment1);
        }
    }
}
