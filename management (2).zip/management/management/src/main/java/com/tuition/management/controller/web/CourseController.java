package com.tuition.management.controller.web;

import com.tuition.management.dto.InstructorDTO;
import com.tuition.management.entity.Course;
import com.tuition.management.service.CourseService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.stream.Collectors;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/courses")
public class CourseController {

    @Autowired
    private CourseService courseService;
    
    
    // ------------------ LIST ------------------
    @GetMapping
    public String listCourses(Model model) {
        model.addAttribute("courses", courseService.findAll());
        model.addAttribute("activeCourses", courseService.countActiveCourses());
        model.addAttribute("availableCourses", courseService.findAvailableCourses().size());
        model.addAttribute("title", "Danh sách khóa học");
        return "courses/list";
    }

    @GetMapping("/active")
    public String listActiveCourses(Model model) {
        model.addAttribute("courses", courseService.findByStatus("ACTIVE"));
        model.addAttribute("title", "Khóa học đang hoạt động");
        return "courses/list";
    }

    @GetMapping("/available")
    public String listAvailableCourses(Model model) {
        model.addAttribute("courses", courseService.findAvailableCourses());
        model.addAttribute("title", "Khóa học còn chỗ");
        return "courses/list";
    }

    @GetMapping("/upcoming")
    public String listUpcomingCourses(Model model) {
        model.addAttribute("courses", courseService.getUpcomingCourses());
        model.addAttribute("title", "Khóa học sắp khai giảng");
        return "courses/list";
    }

    @GetMapping("/schedule")
    public String scheduleCourses(Model model) {
        List<Course> courses = courseService.findAll();
        
        List<Map<String, Object>> courseDTOs = courses.stream().map(course -> {
            Map<String, Object> dto = new HashMap<>();
            dto.put("id", course.getId());
            dto.put("name", course.getName());
            dto.put("description", course.getDescription());
            dto.put("fee", course.getFee());
            dto.put("duration", course.getDuration());
            dto.put("startDate", course.getStartDate());
            dto.put("endDate", course.getEndDate());
            dto.put("scheduleTime", course.getScheduleTime());
            dto.put("scheduleDays", course.getScheduleDays());
            dto.put("roomNumber", course.getRoomNumber());
            dto.put("instructor", course.getInstructor());
            dto.put("instructorEmail", course.getInstructorEmail());
            dto.put("instructorPhone", course.getInstructorPhone());
            dto.put("maxStudents", course.getMaxStudents());
            dto.put("currentStudents", course.getCurrentStudents());
            dto.put("status", course.getStatus());
            return dto;
        }).collect(Collectors.toList());
        
        List<String> instructors = courses.stream()
            .map(Course::getInstructor)
            .filter(Objects::nonNull)
            .distinct()
            .collect(Collectors.toList());
        
        model.addAttribute("courses", courseDTOs);
        model.addAttribute("instructors", instructors);
        model.addAttribute("title", "Lịch học các khóa");
        return "courses/schedule/schedule";
    }
    
    // ==================== GIẢNG VIÊN ====================
    
    @GetMapping("/instructors")
public String listInstructors(Model model) {
    List<Course> courses = courseService.findAll();
    
    // Gom nhóm giảng viên từ các khóa học
    Map<String, InstructorDTO> instructorMap = new LinkedHashMap<>();
    
    for (Course course : courses) {
        String instructorName = course.getInstructor();
        if (instructorName != null && !instructorName.trim().isEmpty()) {
            InstructorDTO instructor = instructorMap.get(instructorName);
            if (instructor == null) {
                instructor = new InstructorDTO();
                instructor.setId((long) instructorName.hashCode());
                instructor.setName(instructorName);
                instructor.setEmail(course.getInstructorEmail() != null ? course.getInstructorEmail() : "");
                instructor.setPhone(course.getInstructorPhone() != null ? course.getInstructorPhone() : "");
                instructor.setCourses(new ArrayList<>());
                instructor.setSpecialty("Giảng viên");
                instructor.setRating(4.5);
                instructor.setStudents(0);
                instructor.setTitle("Giảng viên");
                instructor.setStatus("active");
                instructorMap.put(instructorName, instructor);
            }
            instructor.getCourses().add(course.getName());
        }
    }
    
    List<InstructorDTO> instructors = new ArrayList<>(instructorMap.values());
    
    int totalInstructors = instructors.size();
    int totalCourses = courses.size();
    
    model.addAttribute("instructors", instructors);
    model.addAttribute("totalInstructors", totalInstructors);
    model.addAttribute("activeInstructors", totalInstructors);
    model.addAttribute("totalCourses", totalCourses);
    model.addAttribute("avgRating", 4.5);
    model.addAttribute("title", "Danh sách giảng viên");
    
    return "courses/instructors/instructors";
}

@GetMapping("/instructors/new")
public String showCreateInstructorForm(Model model) {
    model.addAttribute("instructor", new InstructorDTO());
    model.addAttribute("title", "Thêm giảng viên mới");
    return "courses/instructors/form";
}

@PostMapping("/instructors")
public String createInstructor(@ModelAttribute InstructorDTO instructor, RedirectAttributes redirectAttributes) {
    try {
        System.out.println("Thêm giảng viên: " + instructor.getName() + 
                           " - Email: " + instructor.getEmail() + 
                           " - Phone: " + instructor.getPhone());
       
        redirectAttributes.addFlashAttribute("success", "Thêm giảng viên thành công!");
    } catch (Exception e) {
        redirectAttributes.addFlashAttribute("error", "Thêm giảng viên thất bại: " + e.getMessage());
    }
    return "redirect:/courses/instructors";
}

@GetMapping("/instructors/{id}/edit")
public String showEditInstructorForm(@PathVariable Long id, Model model) {
    InstructorDTO instructor = new InstructorDTO();
    instructor.setId(id);
    instructor.setName("Giảng viên " + id);
    instructor.setEmail("giangvien" + id + "@email.com");
    instructor.setPhone("090000000" + id);
    instructor.setTitle("Giảng viên");
    instructor.setSpecialty("Lập trình");
    
    // THÊM SPECIALTIES
    List<String> specialties = new ArrayList<>();
    specialties.add("Java");
    specialties.add("Spring Boot");
    specialties.add("Hibernate");
    instructor.setSpecialties(specialties);
    
    instructor.setStatus("active");
    instructor.setRating(4.5);
    instructor.setExperience(5);
    instructor.setBio("Giảng viên giàu kinh nghiệm");
    
    model.addAttribute("instructor", instructor);
    model.addAttribute("title", "Chỉnh sửa giảng viên");
    return "courses/instructors/form";
}

@PostMapping("/instructors/{id}")
public String updateInstructor(@PathVariable Long id, @ModelAttribute InstructorDTO instructor, RedirectAttributes redirectAttributes) {
    try {
        instructor.setId(id);
        System.out.println("Cập nhật giảng viên ID: " + id + 
                           " - Name: " + instructor.getName() + 
                           " - Email: " + instructor.getEmail());
        redirectAttributes.addFlashAttribute("success", "Cập nhật giảng viên thành công!");
    } catch (Exception e) {
        redirectAttributes.addFlashAttribute("error", "Cập nhật thất bại: " + e.getMessage());
    }
    return "redirect:/courses/instructors";
}

@GetMapping("/instructors/{id}/delete")
public String deleteInstructor(@PathVariable Long id, RedirectAttributes redirectAttributes) {
    try {
        System.out.println("Xóa giảng viên ID: " + id);
        redirectAttributes.addFlashAttribute("success", "Xóa giảng viên thành công!");
    } catch (Exception e) {
        redirectAttributes.addFlashAttribute("error", "Xóa thất bại: " + e.getMessage());
    }
    return "redirect:/courses/instructors";
}

@GetMapping("/{courseId}/instructors/new")
public String showCreateInstructorForCourseForm(@PathVariable Long courseId, Model model) {
    Course course = courseService.findById(courseId)
            .orElseThrow(() -> new RuntimeException("Course not found"));
    model.addAttribute("course", course);
    model.addAttribute("instructor", new InstructorDTO());
    model.addAttribute("title", "Thêm giảng viên cho khóa học: " + course.getName());
    return "courses/instructors/form";
}    // ------------------ CREATE ------------------
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("course", new Course());
        return "courses/form";
    }

    @PostMapping
    public String createCourse(@ModelAttribute Course course, RedirectAttributes redirectAttributes) {
        try {
            courseService.save(course);
            redirectAttributes.addFlashAttribute("success", "Tạo khóa học thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Tạo khóa học thất bại: " + e.getMessage());
        }
        return "redirect:/courses";
    }
    
    // ------------------ VIEW ------------------
    @GetMapping("/{id:\\d+}")
    public String viewCourse(@PathVariable Long id, Model model) {
        Course course = courseService.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        model.addAttribute("course", course);
        model.addAttribute("availableSeats", course.getAvailableSeats());
        return "courses/view";
    }

    // ------------------ EDIT ------------------
    @GetMapping("/{id:\\d+}/edit")
    public String showEditForm(@PathVariable Long id, Model model) {
        Course course = courseService.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        model.addAttribute("course", course);
        return "courses/form";
    }

    @PostMapping("/{id:\\d+}")
    public String updateCourse(@PathVariable Long id, @ModelAttribute Course course,
                               RedirectAttributes redirectAttributes) {
        try {
            courseService.update(id, course);
            redirectAttributes.addFlashAttribute("success", "Cập nhật khóa học thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Cập nhật thất bại: " + e.getMessage());
        }
        return "redirect:/courses";
    }

    // ------------------ DELETE ------------------
    @GetMapping("/{id:\\d+}/delete")
    public String deleteCourse(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            courseService.deleteById(id);
            redirectAttributes.addFlashAttribute("success", "Xóa khóa học thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Xóa thất bại: " + e.getMessage());
        }
        return "redirect:/courses";
    }

    // ------------------ UPDATE STATUS ------------------
    @PostMapping("/{id:\\d+}/status")
    public String updateStatus(@PathVariable Long id, @RequestParam String status,
                               RedirectAttributes redirectAttributes) {
        try {
            courseService.updateStatus(id, status);
            redirectAttributes.addFlashAttribute("success", "Cập nhật trạng thái thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Cập nhật thất bại: " + e.getMessage());
        }
        return "redirect:/courses/" + id;
    }

    // ------------------ SEARCH ------------------
    @GetMapping("/search")
    public String searchCourses(@RequestParam String keyword, Model model) {
        model.addAttribute("courses", courseService.searchCourses(keyword));
        model.addAttribute("keyword", keyword);
        model.addAttribute("title", "Kết quả tìm kiếm: " + keyword);
        return "courses/list";
    }
}