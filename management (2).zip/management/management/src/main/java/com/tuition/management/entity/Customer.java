package com.tuition.management.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "customers")
@Data
public class Customer {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String fullName;
     @DateTimeFormat(pattern = "dd/MM/yyyy") // Thêm annotation này
    
    private LocalDate birthDate;
    
    private String gender;
    
    @Column(unique = true)
    private String email;
    
    private String phone;
    
    private String address;
    
   
     @Column(name = "course")
    private String course;  // Tên khóa học
    
    @Column(name = "course_id")
    private Long courseId;  // ID khóa học
    
    // Getters và Setters
    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }
    
    public Long getCourseId() { return courseId; }
    public void setCourseId(Long courseId) { this.courseId = courseId; }
    private String studentCode; // Mã học viên
    
    private String status; // ACTIVE, INACTIVE, GRADUATED
    
    private String notes;
  
    private LocalDateTime createdAt;
    
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private List<Invoice> invoices;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }
    
}