package com.tuition.management.controller.api;

import com.tuition.management.entity.Payment;
import com.tuition.management.entity.Invoice;
import com.tuition.management.service.PaymentService;
import com.tuition.management.service.InvoiceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/payments")
public class PaymentApi {

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private InvoiceService invoiceService;

    // Lấy tất cả payment
    @GetMapping
    public List<Payment> getAllPayments(){
        return paymentService.getAllPayments();
    }

    // Lấy payment theo id
    @GetMapping("/{id}")
    public Payment getPayment(@PathVariable Long id){
        Optional<Payment> payment = paymentService.getPaymentById(id);
        return payment.orElse(null);
    }

    // Tạo payment
    @PostMapping
    public Payment createPayment(@RequestBody Payment payment){

        Long invoiceId = payment.getInvoice().getId();
        Invoice invoice = invoiceService.getInvoiceById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice not found"));

        payment.setInvoice(invoice);

        return paymentService.createPayment(payment);
    }

    // Update payment
    @PutMapping("/{id}")
    public Payment updatePayment(@PathVariable Long id,
                                 @RequestBody Payment payment){

        payment.setId(id);
        return paymentService.updatePayment(payment);
    }

    // Xóa payment
    @DeleteMapping("/{id}")
    public String deletePayment(@PathVariable Long id){
        paymentService.deletePayment(id);
        return "Deleted";
    }

}