package com.tuition.management.service;

import com.tuition.management.entity.Payment;
import com.tuition.management.entity.Invoice;
import com.tuition.management.repository.PaymentRepository;
import com.tuition.management.repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Transactional
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private InvoiceRepository invoiceRepository;
      public Payment save(Payment payment) {
        return paymentRepository.save(payment);
    }
      public Optional<Payment> findById(Long id) {
        return paymentRepository.findById(id);
    }
    /**
     * Lấy tất cả thanh toán
     */
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    /**
     * Lấy thanh toán theo ID
     */
    public Optional<Payment> getPaymentById(Long id) {
        return paymentRepository.findById(id);
    }

    /**
     * Tạo thanh toán mới
     */
    public Payment createPayment(Payment payment) {
        payment.setPaymentNumber(generatePaymentNumber());
        payment.setStatus("COMPLETED");
        
        Payment savedPayment = paymentRepository.save(payment);
        
        // Cập nhật trạng thái hóa đơn
        updateInvoiceStatus(payment.getInvoice());
        
        return savedPayment;
    }

    /**
     * Cập nhật thanh toán
     */
    public Payment updatePayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    /**
     * Xóa thanh toán
     */
    public void deletePayment(Long id) {
        Optional<Payment> paymentOpt = paymentRepository.findById(id);
        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();
            Invoice invoice = payment.getInvoice();
            
            paymentRepository.deleteById(id);
            
            // Cập nhật lại trạng thái hóa đơn sau khi xóa
            updateInvoiceStatus(invoice);
        }
    }

    /**
     * Lấy thanh toán theo hóa đơn
     */
    public List<Payment> getPaymentsByInvoice(Invoice invoice) {
        return paymentRepository.findByInvoice(invoice);
    }

    /**
     * Lấy thanh toán theo khoảng ngày
     */
    public List<Payment> getPaymentsByDateRange(LocalDate startDate, LocalDate endDate) {
        return paymentRepository.findByPaymentDateBetween(startDate, endDate);
    }

    /**
     * Lấy thanh toán theo ngày cụ thể
     */
    public List<Payment> getPaymentsByDate(LocalDate date) {
        return paymentRepository.findByPaymentDate(date);
    }

    /**
     * Lấy tổng số tiền thanh toán trong khoảng ngày
     */
    public BigDecimal getTotalPaymentAmount(LocalDate startDate, LocalDate endDate) {
        Double amount = paymentRepository.getTotalPaymentAmount(startDate, endDate);
        return amount != null ? BigDecimal.valueOf(amount) : BigDecimal.ZERO;
    }

    /**
     * Lấy thanh toán theo học viên
     */
    public List<Payment> getPaymentsByCustomerId(Long customerId) {
        return paymentRepository.findByCustomerId(customerId);
    }

    /**
     * Tìm kiếm thanh toán
     */
    public List<Payment> searchPayments(String keyword, String method, String fromDate, String toDate) {
        List<Payment> payments = paymentRepository.findAll();
        
        // Filter by keyword
        if (keyword != null && !keyword.isEmpty()) {
            String finalKeyword = keyword.toLowerCase();
            payments = payments.stream()
                    .filter(p -> p.getPaymentNumber().toLowerCase().contains(finalKeyword) ||
                            (p.getInvoice().getCustomer().getFullName().toLowerCase().contains(finalKeyword)) ||
                            (p.getInvoice().getCustomer().getStudentCode().toLowerCase().contains(finalKeyword)) ||
                            (p.getInvoice().getInvoiceNumber().toLowerCase().contains(finalKeyword)))
                    .collect(Collectors.toList());
        }
        
        // Filter by payment method
        if (method != null && !method.isEmpty()) {
            payments = payments.stream()
                    .filter(p -> method.equals(p.getPaymentMethod()))
                    .collect(Collectors.toList());
        }
        
        // Filter by date range
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
        if (fromDate != null && !fromDate.isEmpty()) {
            LocalDate startDate = LocalDate.parse(fromDate, formatter);
            payments = payments.stream()
                    .filter(p -> p.getPaymentDate() != null && !p.getPaymentDate().isBefore(startDate))
                    .collect(Collectors.toList());
        }
        
        if (toDate != null && !toDate.isEmpty()) {
            LocalDate endDate = LocalDate.parse(toDate, formatter);
            payments = payments.stream()
                    .filter(p -> p.getPaymentDate() != null && !p.getPaymentDate().isAfter(endDate))
                    .collect(Collectors.toList());
        }
        
        return payments;
    }

    /**
     * Hủy thanh toán
     */
    public void cancelPayment(Long id) {
        Optional<Payment> paymentOpt = paymentRepository.findById(id);
        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();
            payment.setStatus("CANCELLED");
            paymentRepository.save(payment);
            
            // Cập nhật lại trạng thái hóa đơn
            updateInvoiceStatus(payment.getInvoice());
        }
    }

    /**
     * Cập nhật trạng thái hóa đơn dựa trên các thanh toán
     */
    private void updateInvoiceStatus(Invoice invoice) {
        List<Payment> payments = paymentRepository.findByInvoice(invoice);
       BigDecimal totalPaid = payments.stream()
        .filter(p -> "COMPLETED".equals(p.getStatus()))
        .map(Payment::getAmount)
        .filter(a -> a != null)              // 🔥 FIX SCALE
        .reduce(BigDecimal.ZERO, BigDecimal::add);

BigDecimal totalAmount = invoice.getTotalAmount() != null
        ? invoice.getTotalAmount()
        : BigDecimal.ZERO;

        
        if (totalPaid.compareTo(totalAmount) >= 0) {
            invoice.setStatus("PAID");
        } else if (totalPaid.compareTo(BigDecimal.ZERO) > 0) {
            invoice.setStatus("PARTIAL");
        } else {
            invoice.setStatus("PENDING");
        }
        
        invoiceRepository.save(invoice);
    }

    /**
     * Kiểm tra thanh toán có tồn tại không
     */
    public boolean existsById(Long id) {
        return paymentRepository.existsById(id);
    }

    /**
     * Đếm số thanh toán theo hóa đơn
     */
    public long countByInvoice(Invoice invoice) {
        return paymentRepository.countByInvoice(invoice);
    }

    /**
     * Lấy thanh toán gần đây nhất
     */
    public List<Payment> getRecentPayments(int limit) {
        return paymentRepository.findTopByOrderByPaymentDateDesc(limit);
    }

    /**
     * Tạo mã thanh toán tự động
     */
    private String generatePaymentNumber() {
        String prefix = "PM";
        String timestamp = String.valueOf(System.currentTimeMillis()).substring(7);
        String random = UUID.randomUUID().toString().substring(0, 4).toUpperCase();
        return prefix + timestamp + random;
    }

    /**
     * Lấy thống kê thanh toán theo tháng
     */
    public BigDecimal getMonthlyStats(int month, int year) {
        LocalDate startDate = LocalDate.of(year, month, 1);
        LocalDate endDate = startDate.withDayOfMonth(startDate.lengthOfMonth());
        
        List<Payment> payments = paymentRepository.findByPaymentDateBetween(startDate, endDate);
        return payments.stream()
                .filter(p -> "COMPLETED".equals(p.getStatus()))
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Lấy thống kê thanh toán theo năm
     */
    public BigDecimal getYearlyStats(int year) {
        LocalDate startDate = LocalDate.of(year, 1, 1);
        LocalDate endDate = LocalDate.of(year, 12, 31);
        
        List<Payment> payments = paymentRepository.findByPaymentDateBetween(startDate, endDate);
        return payments.stream()
                .filter(p -> "COMPLETED".equals(p.getStatus()))
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}