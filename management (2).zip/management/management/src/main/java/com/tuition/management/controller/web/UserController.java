package com.tuition.management.controller.web;

import com.tuition.management.entity.User;

import com.tuition.management.service.UserService;
import com.tuition.management.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/users")
@PreAuthorize("hasRole('ADMIN')")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * Hiển thị danh sách người dùng
     */
    @GetMapping
    public String listUsers(Model model) {
        List<User> users = userService.getAllUsers();
        
        // Thống kê
        long totalUsers = users.size();
        long activeUsers = users.stream().filter(User::isEnabled).count();
        long adminCount = users.stream()
                .filter(u -> u.getRoles().stream().anyMatch(r -> "ADMIN".equals(r.getName())))
                .count();
        long staffCount = users.stream()
                .filter(u -> u.getRoles().stream().anyMatch(r -> "STAFF".equals(r.getName())))
                .count();
        
        model.addAttribute("users", users);
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("activeUsers", activeUsers);
        model.addAttribute("adminCount", adminCount);
        model.addAttribute("staffCount", staffCount);
        
        return "users/list";
    }

    /**
     * Hiển thị form tạo người dùng mới
     */
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("user", new User());
        model.addAttribute("roles", roleService.getAllRoles());
        return "users/form";
    }

    /**
     * Hiển thị form chỉnh sửa người dùng
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Optional<User> userOpt = userService.getUserById(id);
        if (userOpt.isPresent()) {
            model.addAttribute("user", userOpt.get());
            model.addAttribute("roles", roleService.getAllRoles());
            return "users/form";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy người dùng");
            return "redirect:/users";
        }
    }

    /**
     * Lưu người dùng (tạo mới hoặc cập nhật)
     */
    @PostMapping("/save")
    public String saveUser(@ModelAttribute User user, 
                          @RequestParam(required = false) List<Long> roleIds,
                          RedirectAttributes redirectAttributes) {
        try {
            // Kiểm tra username đã tồn tại chưa
            if (user.getId() == null) {
                if (userService.existsByUsername(user.getUsername())) {
                    redirectAttributes.addFlashAttribute("error", "Tên đăng nhập đã tồn tại");
                    return "redirect:/users/new";
                }
                // Mã hóa password cho user mới
                user.setPassword(passwordEncoder.encode(user.getPassword()));
            } else {
                // Giữ nguyên password cũ nếu không thay đổi
                Optional<User> existingUser = userService.getUserById(user.getId());
                if (existingUser.isPresent() && (user.getPassword() == null || user.getPassword().isEmpty())) {
                    user.setPassword(existingUser.get().getPassword());
                } else {
                    user.setPassword(passwordEncoder.encode(user.getPassword()));
                }
            }

            // Gán roles
            if (roleIds != null) {
                user.setRoles(roleService.getRolesByIds(roleIds));
            }

            userService.saveUser(user);
            redirectAttributes.addFlashAttribute("success", "Lưu thông tin người dùng thành công!");
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        }
        return "redirect:/users";
    }

    /**
     * Xóa người dùng
     */
    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            // Không cho phép xóa chính mình
            // Cần thêm logic kiểm tra user hiện tại
            
            userService.deleteUser(id);
            redirectAttributes.addFlashAttribute("success", "Xóa người dùng thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Có lỗi khi xóa người dùng: " + e.getMessage());
        }
        return "redirect:/users";
    }

    /**
     * Khóa/Mở khóa người dùng
     */
    @PostMapping("/toggle-status/{id}")
    @ResponseBody
    public String toggleUserStatus(@PathVariable Long id) {
        try {
            Optional<User> userOpt = userService.getUserById(id);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                user.setEnabled(!user.isEnabled());
                userService.saveUser(user);
                return "success";
            }
            return "error: User not found";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    /**
     * Reset mật khẩu
     */
    @PostMapping("/reset-password/{id}")
    public String resetPassword(@PathVariable Long id, 
                                @RequestParam String newPassword,
                                RedirectAttributes redirectAttributes) {
        try {
            Optional<User> userOpt = userService.getUserById(id);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                user.setPassword(passwordEncoder.encode(newPassword));
                userService.saveUser(user);
                redirectAttributes.addFlashAttribute("success", "Reset mật khẩu thành công!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Có lỗi khi reset mật khẩu: " + e.getMessage());
        }
        return "redirect:/users";
    }

    /**
     * Xem chi tiết người dùng
     */
    @GetMapping("/view/{id}")
    public String viewUser(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Optional<User> userOpt = userService.getUserById(id);
        if (userOpt.isPresent()) {
            model.addAttribute("user", userOpt.get());
            return "users/view";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy người dùng");
            return "redirect:/users";
        }
    }

    /**
     * Tìm kiếm người dùng
     */
    @GetMapping("/search")
    public String searchUsers(@RequestParam String keyword, Model model) {
        List<User> users = userService.searchUsers(keyword);
        model.addAttribute("users", users);
        model.addAttribute("keyword", keyword);
        
        // Thống kê
        model.addAttribute("totalUsers", users.size());
        model.addAttribute("activeUsers", users.stream().filter(User::isEnabled).count());
        
        return "users/list";
    }
}