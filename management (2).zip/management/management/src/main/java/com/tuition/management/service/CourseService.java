package com.tuition.management.service;

import com.tuition.management.entity.Course;
import com.tuition.management.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class CourseService {
    
    @Autowired
    private CourseRepository courseRepository;
    
    public List<Course> findAll() {
        return courseRepository.findAll();
    }
    
    
    public Optional<Course> findById(Long id) {
        return courseRepository.findById(id);
    }
    
    public List<Course> findByStatus(String status) {
        return courseRepository.findByStatus(status);
    }
    
    public List<Course> findAvailableCourses() {
        return courseRepository.findAvailableCourses();
    }
    
    public List<Course> searchCourses(String keyword) {
        return courseRepository.searchCourses(keyword);
    }
    
    @Transactional
    public Course save(Course course) {
        if (course.getStatus() == null) {
            course.setStatus("ACTIVE");
        }
        if (course.getCurrentStudents() == null) {
            course.setCurrentStudents(0);
        }
        return courseRepository.save(course);
    }
    
    @Transactional
    public Course update(Long id, Course courseDetails) {
        Course course = courseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Course not found"));
        
        course.setName(courseDetails.getName());
        course.setDescription(courseDetails.getDescription());
        course.setFee(courseDetails.getFee());
        course.setDuration(courseDetails.getDuration());
        course.setStartDate(courseDetails.getStartDate());
        course.setEndDate(courseDetails.getEndDate());
        course.setScheduleTime(courseDetails.getScheduleTime());
        course.setScheduleDays(courseDetails.getScheduleDays());
        course.setRoomNumber(courseDetails.getRoomNumber());
        course.setInstructor(courseDetails.getInstructor());
        course.setInstructorEmail(courseDetails.getInstructorEmail());
        course.setInstructorPhone(courseDetails.getInstructorPhone());
        course.setMaxStudents(courseDetails.getMaxStudents());
        course.setStatus(courseDetails.getStatus());
        
        return courseRepository.save(course);
    }
    
    @Transactional
    public void deleteById(Long id) {
        courseRepository.deleteById(id);
    }
    
    @Transactional
    public void updateStatus(Long id, String status) {
        Course course = courseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setStatus(status);
        courseRepository.save(course);
    }
    
    @Transactional
    public void incrementStudentCount(Long id) {
        Course course = courseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Course not found"));
        if (course.getCurrentStudents() < course.getMaxStudents()) {
            course.setCurrentStudents(course.getCurrentStudents() + 1);
            courseRepository.save(course);
        } else {
            throw new RuntimeException("Course is full");
        }
    }
    
    @Transactional
    public void decrementStudentCount(Long id) {
        Course course = courseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Course not found"));
        if (course.getCurrentStudents() > 0) {
            course.setCurrentStudents(course.getCurrentStudents() - 1);
            courseRepository.save(course);
        }
    }
    
    public Long countActiveCourses() {
        return courseRepository.countActiveCourses();
    }
    
    public Double getAverageOccupancyRate() {
        return courseRepository.getAverageOccupancyRate();
    }
    
    public List<Course> getUpcomingCourses() {
        return courseRepository.findByStatusAndStartDateAfter("ACTIVE", LocalDate.now());
    }
    
}