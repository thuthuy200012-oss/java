package com.tuition.management.controller.web;

import com.tuition.management.entity.Course;
import com.tuition.management.entity.Customer;
import com.tuition.management.entity.Invoice;
import com.tuition.management.entity.Payment;
import com.tuition.management.service.CourseService;
import com.tuition.management.service.CustomerService;
import com.tuition.management.service.InvoiceService;
import com.tuition.management.service.PaymentService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/customers")
public class CustomerController {
    
    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private CourseService courseService; // Thêm CourseService

    @GetMapping
    public String listCustomers(Model model) {
        var customers = customerService.getAllCustomers();

        model.addAttribute("customers", customers);
        model.addAttribute("totalCustomers", customers.size());
        model.addAttribute("activeStudents",
                customers.stream().filter(c -> "ACTIVE".equals(c.getStatus())).count());
        model.addAttribute("inactiveStudents",
                customers.stream().filter(c -> "INACTIVE".equals(c.getStatus())).count());
        model.addAttribute("graduatedStudents",
                customers.stream().filter(c -> "GRADUATED".equals(c.getStatus())).count());

        return "customers/list";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("customer", new Customer());
        // Lấy danh sách khóa học từ database
        List<Course> courses = courseService.findAll();
        model.addAttribute("courses", courses);
        return "customers/form";
    }

    @PostMapping("/save")
public String saveCustomer(@ModelAttribute Customer customer, 
                            @RequestParam(value = "courseId", required = false) Long courseId,
                            RedirectAttributes redirectAttributes) {
    try {
        // THÊM LOG NÀY
        System.out.println("=== SAVE CUSTOMER ===");
        System.out.println("courseId nhận được: " + courseId);
        System.out.println("customer name: " + customer.getFullName());
        
        // Xử lý khóa học nếu có
        if (courseId != null) {
            Optional<Course> courseOpt = courseService.findById(courseId);
            if (courseOpt.isPresent()) {
                Course course = courseOpt.get();
                customer.setCourse(course.getName());
                customer.setCourseId(courseId);
                System.out.println("✅ Đã set course: " + course.getName() + " (ID: " + courseId + ")");
            }
        } else {
            System.out.println("⚠️ courseId = null, không set khóa học");
        }
        
        Customer saved = customerService.saveCustomer(customer);
        System.out.println("✅ Đã lưu customer ID: " + saved.getId());
        System.out.println("   Course ID trong DB: " + saved.getCourseId());
        System.out.println("   Course name: " + saved.getCourse());
        
        redirectAttributes.addFlashAttribute("success", "Lưu thông tin học viên thành công!");
    } catch (Exception e) {
        System.err.println("❌ Lỗi: " + e.getMessage());
        e.printStackTrace();
        redirectAttributes.addFlashAttribute("error", "Lưu thông tin học viên thất bại: " + e.getMessage());
    }
    return "redirect:/customers";
}
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Optional<Customer> customerOpt = customerService.getCustomerById(id);
        if (customerOpt.isPresent()) {
            model.addAttribute("customer", customerOpt.get());
        }
        // Lấy danh sách khóa học từ database
        List<Course> courses = courseService.findAll();
        model.addAttribute("courses", courses);
        return "customers/form";
    }

    @PostMapping("/update/{id}")
    public String updateCustomer(@PathVariable Long id,
                                  @ModelAttribute Customer customer,
                                  @RequestParam(value = "courseId", required = false) Long courseId,
                                  RedirectAttributes redirectAttributes) {
        try {
            // Xử lý khóa học nếu có
            if (courseId != null) {
                Optional<Course> courseOpt = courseService.findById(courseId);
                if (courseOpt.isPresent()) {
                    Course course = courseOpt.get();
                    customer.setCourse(course.getName());
                    customer.setCourseId(courseId);
                }
            }
            
            customer.setId(id);
            customerService.saveCustomer(customer);
            redirectAttributes.addFlashAttribute("success", "Cập nhật học viên thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Cập nhật thất bại: " + e.getMessage());
        }
        return "redirect:/customers";
    }

    @GetMapping("/delete/{id}")
    public String deleteCustomer(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            customerService.deleteCustomer(id);
            redirectAttributes.addFlashAttribute("success", "Xóa học viên thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Xóa học viên thất bại: " + e.getMessage());
        }
        return "redirect:/customers";
    }

    @GetMapping("/view/{id}")
    public String viewCustomer(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Optional<Customer> customerOpt = customerService.getCustomerById(id);
        
        if (customerOpt.isPresent()) {
            Customer customer = customerOpt.get();
            
            // Lấy danh sách hóa đơn của học viên
            List<Invoice> invoices = invoiceService.getInvoicesByCustomer(customer);
            
            // Tính toán số tiền đã thanh toán cho mỗi hóa đơn
            for (Invoice invoice : invoices) {
                List<Payment> payments = paymentService.getPaymentsByInvoice(invoice);
                BigDecimal paidAmount = payments.stream()
                        .filter(p -> "COMPLETED".equals(p.getStatus()))
                        .map(Payment::getAmount)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
                
                invoice.setPaidAmount(paidAmount);
            }
            
            // Lấy lịch sử thanh toán của học viên
            List<Payment> payments = paymentService.getPaymentsByCustomerId(id);
            
            // Thống kê
            long invoiceCount = invoices.size();
            long paidCount = invoices.stream()
                    .filter(i -> "PAID".equals(i.getStatus()))
                    .count();
            long pendingCount = invoices.stream()
                    .filter(i -> "PENDING".equals(i.getStatus()) || "OVERDUE".equals(i.getStatus()))
                    .count();
            
            BigDecimal totalPaid = payments.stream()
                    .filter(p -> "COMPLETED".equals(p.getStatus()))
                    .map(Payment::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Thêm vào model
            model.addAttribute("customer", customer);
            model.addAttribute("invoices", invoices);
            model.addAttribute("payments", payments);
            model.addAttribute("invoiceCount", invoiceCount);
            model.addAttribute("paidCount", paidCount);
            model.addAttribute("pendingCount", pendingCount);
            model.addAttribute("totalPaid", totalPaid);
            
            return "customers/view";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy học viên với ID: " + id);
            return "redirect:/customers";
        }
    }

    @GetMapping("/search")
    public String searchCustomers(@RequestParam String keyword, Model model) {
        model.addAttribute("customers", customerService.searchCustomers(keyword));
        model.addAttribute("keyword", keyword);
        return "customers/list";
    }
}