package com.tuition.management.controller.api;

import com.tuition.management.entity.Invoice;
import com.tuition.management.service.InvoiceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceApi {

    @Autowired
    private InvoiceService invoiceService;

    // Lấy tất cả hóa đơn
    @GetMapping
    public List<Invoice> getAllInvoices() {
        return invoiceService.getAllInvoices();
    }

    // Lấy hóa đơn theo ID
    @GetMapping("/{id}")
    public Invoice getInvoice(@PathVariable Long id) {
        Optional<Invoice> invoice = invoiceService.getInvoiceById(id);
        return invoice.orElse(null);
    }

    // Tạo hóa đơn
    @PostMapping
    public Invoice createInvoice(@RequestBody Invoice invoice) {
        return invoiceService.createInvoice(invoice);
    }

    // Cập nhật hóa đơn
    @PutMapping("/{id}")
    public Invoice updateInvoice(@PathVariable Long id, @RequestBody Invoice invoice) {
        invoice.setId(id);
        return invoiceService.updateInvoice(invoice);
    }

    // Xóa hóa đơn
    @DeleteMapping("/{id}")
    public String deleteInvoice(@PathVariable Long id) {
        invoiceService.deleteInvoice(id);
        return "Deleted";
    }

    // Cập nhật trạng thái hóa đơn
    @PutMapping("/{id}/status")
    public String updateStatus(@PathVariable Long id, @RequestParam String status) {
        Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(id);
        if(invoiceOpt.isPresent()){
            Invoice invoice = invoiceOpt.get();
            invoice.setStatus(status);
            invoiceService.updateInvoice(invoice);
            return "success";
        }
        return "invoice not found";
    }
}