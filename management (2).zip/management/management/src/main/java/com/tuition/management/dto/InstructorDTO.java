package com.tuition.management.dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class InstructorDTO {
    private Long id;
    private String name;
    private String email;
    private String phone;
    private List<String> courses = new ArrayList<>();
    private List<String> specialties = new ArrayList<>(); // THÊM NÀY
    private String specialty;
    private Double rating;
    private Integer students;
    private String title;
    private String status;
    private Integer experience;
    private String bio;
    private String address;
    private String gender;
    private String birthday;
    private String facebook;
    private String linkedin;
    private String github;
    private String website;
    private String username;
    private String startDate;
    private Integer courseCount;
    // Thêm vào InstructorDTO.java
private LocalDateTime createdAt;
private LocalDateTime updatedAt;

public LocalDateTime getCreatedAt() { return createdAt; }
public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

public LocalDateTime getUpdatedAt() { return updatedAt; }
public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
    public InstructorDTO() {}
    
    public InstructorDTO(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.courses = new ArrayList<>();
        this.specialties = new ArrayList<>();
        this.specialty = "Giảng viên";
        this.rating = 4.5;
        this.students = 0;
        this.title = "Giảng viên";
        this.status = "active";
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public List<String> getCourses() { return courses; }
    public void setCourses(List<String> courses) { this.courses = courses; }
    
    public List<String> getSpecialties() { return specialties; }
    public void setSpecialties(List<String> specialties) { this.specialties = specialties; }
    
    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }
    
    public Double getRating() { return rating; }
    public void setRating(Double rating) { this.rating = rating; }
    
    public Integer getStudents() { return students; }
    public void setStudents(Integer students) { this.students = students; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Integer getExperience() { return experience; }
    public void setExperience(Integer experience) { this.experience = experience; }
    
    public String getBio() { return bio; }
    public void setBio(String bio) { this.bio = bio; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getBirthday() { return birthday; }
    public void setBirthday(String birthday) { this.birthday = birthday; }
    
    public String getFacebook() { return facebook; }
    public void setFacebook(String facebook) { this.facebook = facebook; }
    
    public String getLinkedin() { return linkedin; }
    public void setLinkedin(String linkedin) { this.linkedin = linkedin; }
    
    public String getGithub() { return github; }
    public void setGithub(String github) { this.github = github; }
    
    public String getWebsite() { return website; }
    public void setWebsite(String website) { this.website = website; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }
    
    public Integer getCourseCount() { 
        return courseCount != null ? courseCount : courses.size(); 
    }
    public void setCourseCount(Integer courseCount) { this.courseCount = courseCount; }
    
    public int getCourseCountValue() {
        return courses != null ? courses.size() : 0;
    }
}