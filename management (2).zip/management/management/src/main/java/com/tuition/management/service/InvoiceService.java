package com.tuition.management.service;

import com.tuition.management.entity.Invoice;
import com.tuition.management.entity.Customer;
import com.tuition.management.repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class InvoiceService {
    
    @Autowired
    private InvoiceRepository invoiceRepository;
     public Optional<Invoice> findById(Long id) {
        return invoiceRepository.findById(id);
    }

    // Lưu hóa đơn
    public Invoice save(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }
    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }
    /**
 * Tìm hóa đơn theo ngày đến hạn
 */
public List<Invoice> findByDueDate(LocalDate dueDate) {
    return invoiceRepository.findByDueDate(dueDate);
}

/**
 * Tìm hóa đơn quá hạn
 */
public List<Invoice> findOverdueInvoices() {
    return invoiceRepository.findOverdueInvoices(LocalDate.now());
}

/**
 * Tìm hóa đơn sắp đến hạn (trong khoảng ngày)
 */
public List<Invoice> findUpcomingInvoices(int days) {
    LocalDate startDate = LocalDate.now();
    LocalDate endDate = LocalDate.now().plusDays(days);
    return invoiceRepository.findInvoicesDueBetween(startDate, endDate);
}
    public Optional<Invoice> getInvoiceById(Long id) {
        return invoiceRepository.findById(id);
    }

    public Optional<Invoice> getInvoiceByNumber(String invoiceNumber) {
        return invoiceRepository.findByInvoiceNumber(invoiceNumber);
    }
    
    public Invoice createInvoice(Invoice invoice) {
        invoice.setInvoiceNumber(generateInvoiceNumber());
        invoice.setStatus("PENDING");
        return invoiceRepository.save(invoice);
    }

    public Invoice updateInvoice(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }

    public void deleteInvoice(Long id) {
        invoiceRepository.deleteById(id);
    }

    public List<Invoice> getInvoicesByCustomer(Customer customer) {
        return invoiceRepository.findByCustomer(customer);
    }

    public List<Invoice> getOverdueInvoices() {
        return invoiceRepository.findByDueDateBeforeAndStatus(LocalDate.now(), "PENDING");
    }

    public BigDecimal getTotalRevenue(LocalDate startDate, LocalDate endDate) {
        return invoiceRepository.getTotalInvoiceAmount(startDate, endDate);
    }

    private String generateInvoiceNumber() {
        return "INV" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
    }
    
    public List<Invoice> searchInvoices(String keyword, String status, Integer month, Integer year) {
    return invoiceRepository.searchInvoices(keyword, status, month, year);
}

public List<Invoice> getInvoicesByDateRange(LocalDate startDate, LocalDate endDate) {
    return invoiceRepository.findByIssueDateBetween(startDate, endDate);
}

}