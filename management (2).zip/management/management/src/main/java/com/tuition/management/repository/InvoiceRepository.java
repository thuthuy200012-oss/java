package com.tuition.management.repository;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.tuition.management.entity.Invoice;
import com.tuition.management.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    
    // Tìm hóa đơn theo ngày đến hạn
    List<Invoice> findByDueDate(LocalDate dueDate);
    
    // Tìm hóa đơn theo trạng thái
    List<Invoice> findByStatus(String status);
    
    // Tìm hóa đơn quá hạn (chưa thanh toán)
    @Query("SELECT i FROM Invoice i WHERE i.dueDate < :today AND i.status != 'PAID'")
    List<Invoice> findOverdueInvoices(@Param("today") LocalDate today);
    
    // Tìm hóa đơn trong khoảng thời gian
    @Query("SELECT i FROM Invoice i WHERE i.dueDate BETWEEN :startDate AND :endDate AND i.status != 'PAID'")
    List<Invoice> findInvoicesDueBetween(@Param("startDate") LocalDate startDate, 
                                          @Param("endDate") LocalDate endDate);

    // Tìm hóa đơn theo số hóa đơn
    Optional<Invoice> findByInvoiceNumber(String invoiceNumber);
    
    // Tìm hóa đơn theo khách hàng
    List<Invoice> findByCustomer(Customer customer);
    
    // Tìm hóa đơn theo khách hàng và trạng thái
    @Query("SELECT i FROM Invoice i WHERE i.customer.id = :customerId AND i.status = :status")
    List<Invoice> findByCustomerAndStatus(@Param("customerId") Long customerId, 
                                          @Param("status") String status);
    
    // Tìm hóa đơn theo ngày và trạng thái (method naming convention)
    List<Invoice> findByDueDateBeforeAndStatus(LocalDate date, String status);
    
    // Tìm hóa đơn quá hạn và chưa thanh toán (cách viết khác)
    @Query("SELECT i FROM Invoice i WHERE i.dueDate < :date AND i.status != :status")
    List<Invoice> findOverdueByDateAndStatus(@Param("date") LocalDate date, @Param("status") String status);
    
    // Tính tổng tiền hóa đơn theo khoảng thời gian
    @Query("SELECT SUM(i.amount) FROM Invoice i WHERE i.issueDate BETWEEN :startDate AND :endDate")
    BigDecimal getTotalInvoiceAmount(@Param("startDate") LocalDate startDate, 
                                     @Param("endDate") LocalDate endDate);
    
    // 🔎 Tìm kiếm hóa đơn (search)
    @Query("""
        SELECT i FROM Invoice i
        WHERE
        (:keyword IS NULL OR LOWER(i.invoiceNumber) LIKE LOWER(CONCAT('%', :keyword, '%')))
        AND (:status IS NULL OR i.status = :status)
        AND (:month IS NULL OR MONTH(i.issueDate) = :month)
        AND (:year IS NULL OR YEAR(i.issueDate) = :year)
    """)
    List<Invoice> searchInvoices(
            @Param("keyword") String keyword,
            @Param("status") String status,
            @Param("month") Integer month,
            @Param("year") Integer year
    );
    
    // 📅 Lấy hóa đơn theo khoảng ngày
    List<Invoice> findByIssueDateBetween(LocalDate startDate, LocalDate endDate);
    
}