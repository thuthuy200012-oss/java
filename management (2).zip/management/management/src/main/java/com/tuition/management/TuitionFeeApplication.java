package com.tuition.management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling  // BẮT BUỘC PHẢI CÓ
public class TuitionFeeApplication {
    public static void main(String[] args) {
        SpringApplication.run(TuitionFeeApplication.class, args);
        System.out.println("🚀 Hệ thống đã khởi động!");
        System.out.println("📧 Tự động gửi nhắc nhở học phí vào 8:00, 14:00, 20:00 hàng ngày");
    }
}