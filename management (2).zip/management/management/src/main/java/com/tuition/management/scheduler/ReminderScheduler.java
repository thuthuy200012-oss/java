package com.tuition.management.scheduler;

import com.tuition.management.entity.Invoice;
import com.tuition.management.service.EmailService;
import com.tuition.management.service.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;

@Component
@EnableScheduling
public class ReminderScheduler {

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private EmailService emailService;

    /**
     * Chạy tự động mỗi ngày lúc 8:00 AM
     * Gửi nhắc nhở cho hóa đơn còn 3 ngày đến hạn
     */
    @Scheduled(cron = "0 0 8 * * ?")
    public void sendThreeDaysReminder() {
        System.out.println("\n========================================");
        System.out.println("📧 BẮT ĐẦU GỬI NHẮC NHỞ HỌC PHÍ");
        System.out.println("Thời gian: " + java.time.LocalDateTime.now());
        System.out.println("========================================");
        
        // Lấy ngày đến hạn là 3 ngày tới
        LocalDate targetDate = LocalDate.now().plusDays(3);
        List<Invoice> invoices = invoiceService.findByDueDate(targetDate);
        
        int sentCount = 0;
        for (Invoice invoice : invoices) {
            // Chỉ gửi cho hóa đơn chưa thanh toán
            if (!"PAID".equals(invoice.getStatus())) {
                emailService.sendInvoiceReminder(invoice.getCustomer(), invoice);
                sentCount++;
                
                // Cập nhật trạng thái đã gửi nhắc nhở (nếu có field reminder_sent)
                // invoice.setReminderSent(true);
                // invoiceService.save(invoice);
            }
        }
        
        System.out.println("========================================");
        System.out.println("✅ Đã gửi " + sentCount + " email nhắc nhở");
        System.out.println("📅 Ngày đến hạn: " + targetDate);
        System.out.println("========================================\n");
    }
    
    /**
     * Chạy mỗi ngày lúc 14:00 để gửi nhắc nhở cho hóa đơn sắp hạn (1-2 ngày)
     */
    @Scheduled(cron = "0 0 14 * * ?")
    public void sendUrgentReminder() {
        System.out.println("\n📧 GỬI NHẮC NHỞ KHẨN CẤP - " + java.time.LocalDateTime.now());
        
        // Gửi nhắc nhở cho hóa đơn còn 1 ngày và 2 ngày
        LocalDate oneDayLater = LocalDate.now().plusDays(1);
        LocalDate twoDaysLater = LocalDate.now().plusDays(2);
        
        List<Invoice> invoices1 = invoiceService.findByDueDate(oneDayLater);
        List<Invoice> invoices2 = invoiceService.findByDueDate(twoDaysLater);
        
        int sentCount = 0;
        for (Invoice invoice : invoices1) {
            if (!"PAID".equals(invoice.getStatus())) {
                emailService.sendInvoiceReminder(invoice.getCustomer(), invoice);
                sentCount++;
            }
        }
        for (Invoice invoice : invoices2) {
            if (!"PAID".equals(invoice.getStatus())) {
                emailService.sendInvoiceReminder(invoice.getCustomer(), invoice);
                sentCount++;
            }
        }
        
        System.out.println("✅ Đã gửi " + sentCount + " email nhắc nhở khẩn cấp");
    }
     /**
     * Chạy mỗi ngày lúc 10:35 AM
     * Gửi nhắc nhở bổ sung cho hóa đơn còn 2-3 ngày
     */
    @Scheduled(cron = "0 29 11 * * ?")
    public void sendMidMorningReminder() {
        System.out.println("\n📧 GỬI NHẮC NHỞ GIỮA SÁNG - 10:35 - " + java.time.LocalDateTime.now());
        
        // Gửi nhắc nhở cho hóa đơn còn 2 ngày và 3 ngày
        LocalDate twoDaysLater = LocalDate.now().plusDays(2);
        LocalDate threeDaysLater = LocalDate.now().plusDays(3);
        
        List<Invoice> invoices2Days = invoiceService.findByDueDate(twoDaysLater);
        List<Invoice> invoices3Days = invoiceService.findByDueDate(threeDaysLater);
        
        int sentCount = 0;
        for (Invoice invoice : invoices2Days) {
            if (!"PAID".equals(invoice.getStatus())) {
                emailService.sendInvoiceReminder(invoice.getCustomer(), invoice);
                sentCount++;
            }
        }
        for (Invoice invoice : invoices3Days) {
            if (!"PAID".equals(invoice.getStatus())) {
                emailService.sendInvoiceReminder(invoice.getCustomer(), invoice);
                sentCount++;
            }
        }
        
        System.out.println("✅ Đã gửi " + sentCount + " email nhắc nhở lúc 10:35");
    }
    
    /**
     * Chạy mỗi ngày lúc 20:00 để gửi nhắc nhở cho hóa đơn quá hạn
     */
    @Scheduled(cron = "0 0 20 * * ?")
    public void sendOverdueReminder() {
        System.out.println("\n📧 GỬI NHẮC NHỞ QUÁ HẠN - " + java.time.LocalDateTime.now());
        
        List<Invoice> overdueInvoices = invoiceService.findOverdueInvoices();
        
        int sentCount = 0;
        for (Invoice invoice : overdueInvoices) {
            emailService.sendInvoiceReminder(invoice.getCustomer(), invoice);
            sentCount++;
        }
        
        System.out.println("✅ Đã gửi " + sentCount + " email nhắc nhở quá hạn");
    }
}