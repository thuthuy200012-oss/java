package com.tuition.management.controller.web;

import com.tuition.management.entity.Invoice;
import com.tuition.management.entity.Payment;
import com.tuition.management.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/payments")
public class PaymentPrintController {

    @Autowired
    private PaymentService paymentService;  // Chỉ cần PaymentService

    @GetMapping("/print/{paymentId}")
    public String printInvoiceByPayment(@PathVariable Long paymentId, Model model, RedirectAttributes redirectAttributes) {
        try {
            // Tìm payment theo ID
            Payment payment = paymentService.findById(paymentId)
                    .orElseThrow(() -> new RuntimeException("Không tìm thấy payment ID: " + paymentId));
            
            // Lấy invoice từ payment
            Invoice invoice = payment.getInvoice();
            if (invoice == null) {
                throw new RuntimeException("Payment ID " + paymentId + " không có hóa đơn liên kết");
            }
            
            System.out.println("=== IN HÓA ĐƠN ===");
            System.out.println("Payment ID: " + paymentId);
            System.out.println("Invoice ID: " + invoice.getId());
            System.out.println("Invoice Number: " + invoice.getInvoiceNumber());
            
            model.addAttribute("invoice", invoice);
            model.addAttribute("payment", payment);
            return "payments/print";
            
        } catch (Exception e) {
            System.err.println("Lỗi: " + e.getMessage());
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/payments";
        }
    }
}