package com.tuition.management.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "courses")
public class Course {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column(length = 500)
    private String description;
    
    @Column(nullable = false)
    private Double fee;
    
    @Column(nullable = false)
    private Integer duration; // số buổi học
    
    @Column(name = "start_date")
    @DateTimeFormat(pattern = "dd/MM/yyyy") 
    private LocalDate startDate;
    
    @Column(name = "end_date")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate endDate;
    
    @Column(name = "schedule_time")
    private LocalTime scheduleTime;
    
    @Column(name = "schedule_days")
    private String scheduleDays; // VD: "MON,WED,FRI" hoặc "TUE,THU"
    
    @Column(name = "room_number")
    private String roomNumber;
    
    @Column(nullable = false)
    private String instructor; // tên giảng viên
    
    @Column(name = "instructor_email")
    private String instructorEmail;
    
    @Column(name = "instructor_phone")
    private String instructorPhone;
    
    @Column(nullable = false)
    private Integer maxStudents = 30;
    
    @Column(nullable = false)
    private Integer currentStudents = 0;
    
    private String status = "ACTIVE"; // ACTIVE, COMPLETED, CANCELLED
    
    // ===== THÊM createdAt VÀ updatedAt =====
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    // ======================================
    
    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Invoice> invoices = new ArrayList<>();
    
    // Constructors
    public Course() {}
    
    public Course(String name, String description, Double fee, Integer duration, 
                  LocalDate startDate, LocalDate endDate, String instructor) {
        this.name = name;
        this.description = description;
        this.fee = fee;
        this.duration = duration;
        this.startDate = startDate;
        this.endDate = endDate;
        this.instructor = instructor;
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Double getFee() {
        return fee;
    }
    
    public void setFee(Double fee) {
        this.fee = fee;
    }
    
    public Integer getDuration() {
        return duration;
    }
    
    public void setDuration(Integer duration) {
        this.duration = duration;
    }
    
    public LocalDate getStartDate() {
        return startDate;
    }
    
    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }
    
    public LocalDate getEndDate() {
        return endDate;
    }
    
    public void setEndDate(LocalDate endDate) {
        this.endDate = endDate;
    }
    
    public LocalTime getScheduleTime() {
        return scheduleTime;
    }
    
    public void setScheduleTime(LocalTime scheduleTime) {
        this.scheduleTime = scheduleTime;
    }
    
    public String getScheduleDays() {
        return scheduleDays;
    }
    
    public void setScheduleDays(String scheduleDays) {
        this.scheduleDays = scheduleDays;
    }
    
    public String getRoomNumber() {
        return roomNumber;
    }
    
    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }
    
    public String getInstructor() {
        return instructor;
    }
    
    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }
    
    public String getInstructorEmail() {
        return instructorEmail;
    }
    
    public void setInstructorEmail(String instructorEmail) {
        this.instructorEmail = instructorEmail;
    }
    
    public String getInstructorPhone() {
        return instructorPhone;
    }
    
    public void setInstructorPhone(String instructorPhone) {
        this.instructorPhone = instructorPhone;
    }
    
    public Integer getMaxStudents() {
        return maxStudents;
    }
    
    public void setMaxStudents(Integer maxStudents) {
        this.maxStudents = maxStudents;
    }
    
    public Integer getCurrentStudents() {
        return currentStudents;
    }
    
    public void setCurrentStudents(Integer currentStudents) {
        this.currentStudents = currentStudents;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    // ===== GETTERS VÀ SETTERS CHO createdAt VÀ updatedAt =====
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    // =========================================================
    
    public List<Invoice> getInvoices() {
        return invoices;
    }
    
    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }
    
    public boolean isAvailable() {
        return currentStudents < maxStudents;
    }
    
    public int getAvailableSeats() {
        return maxStudents - currentStudents;
    }
    
    // ===== THÊM CÁC METHOD TỰ ĐỘNG CẬP NHẬT THỜI GIAN =====
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    // ========================================================
}