package com.tuition.management.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "invoices")
@Data
public class Invoice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String invoiceNumber;

    @ManyToOne
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;

    @ManyToOne
    @JoinColumn(name = "course_id")
    private Course course;

    private String description;

    @Column(nullable = false)
    private BigDecimal amount;

    private BigDecimal discount = BigDecimal.ZERO;

    private BigDecimal tax = BigDecimal.ZERO;

    @Column(nullable = false)
    private BigDecimal totalAmount = BigDecimal.ZERO;

    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate issueDate;
    // Thêm quan hệ với Course
   

    // Thêm trường courseId
    @Column(name = "course_id", insertable = false, updatable = false)
    private Long courseId;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate dueDate;

    private String status; // PENDING, PAID, OVERDUE, CANCELLED

    private String paymentMethod;

    private String notes;

    @OneToMany(mappedBy = "invoice", cascade = CascadeType.ALL)
    private List<Payment> payments;
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    @ManyToOne
    @JoinColumn(name = "created_by")
    private User createdBy;

    private LocalDateTime createdAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (issueDate == null) issueDate = LocalDate.now();
        calculateTotalAmount();
    }

    @PreUpdate
    protected void onUpdate() {
        calculateTotalAmount();
    }

    /**
     * Tính tổng tiền
     */
    private void calculateTotalAmount() {
        if (amount != null) {
            BigDecimal afterDiscount = amount.subtract(discount != null ? discount : BigDecimal.ZERO);
            BigDecimal taxAmount = afterDiscount.multiply(tax != null ? tax : BigDecimal.ZERO)
                    .divide(new BigDecimal("100"));
            totalAmount = afterDiscount.add(taxAmount);
        } else {
            totalAmount = BigDecimal.ZERO;
        }
    }

    // Các field transient
    @Transient
    private BigDecimal paidAmount;

    @Transient
    private BigDecimal remainingAmount;

    @Transient
    private Integer daysUntilDue;

    public BigDecimal getRemainingAmount() {
        if (getTotalAmount() != null && paidAmount != null) {
            return getTotalAmount().subtract(paidAmount);
        }
        return remainingAmount;
    }

    public void setRemainingAmount(BigDecimal remainingAmount) {
        this.remainingAmount = remainingAmount;
    }

    public Integer getDaysUntilDue() {
        return daysUntilDue;
    }

    public void setDaysUntilDue(Integer daysUntilDue) {
        this.daysUntilDue = daysUntilDue;
    }
}