package com.tuition.management.dto;

public class PaymentDTO {
    
}
