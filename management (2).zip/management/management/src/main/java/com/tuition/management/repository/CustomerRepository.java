package com.tuition.management.repository;

import com.tuition.management.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    
    // Tìm theo mã học viên
    Optional<Customer> findByStudentCode(String studentCode);
    
    // Tìm theo email
    Optional<Customer> findByEmail(String email);
    
    // Tìm theo trạng thái
    List<Customer> findByStatus(String status);
    
    // Tìm theo khóa học (course_id)
    List<Customer> findByCourseId(Long courseId);
    
    // Tìm kiếm theo từ khóa
    @Query("SELECT c FROM Customer c WHERE " +
           "LOWER(c.fullName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.studentCode) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.phone) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.email) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Customer> search(@Param("keyword") String keyword);
    
    // Đếm số học viên theo khóa học
    long countByCourseId(Long courseId);
    
    // Đếm số học viên theo khóa học và trạng thái
    long countByCourseIdAndStatus(Long courseId, String status);
    
    // Đếm số học viên mới theo khóa học (tạo sau ngày)
    @Query("SELECT COUNT(c) FROM Customer c WHERE c.courseId = :courseId AND c.createdAt >= :date")
    long countByCourseIdAndCreatedAtAfter(@Param("courseId") Long courseId, @Param("date") LocalDate date);
    
    // Lấy tất cả học viên theo khóa học
    @Query("SELECT c FROM Customer c WHERE c.courseId = :courseId ORDER BY c.createdAt DESC")
    List<Customer> findByCourseIdOrderByCreatedAtDesc(@Param("courseId") Long courseId);
    
    // Lấy học viên đang hoạt động
    List<Customer> findByStatusOrderByCreatedAtDesc(String status);
    
    // Đếm tổng số học viên
    @Query("SELECT COUNT(c) FROM Customer c")
    long countAllCustomers();
    
    // Đếm học viên mới trong tháng
    @Query("SELECT COUNT(c) FROM Customer c WHERE YEAR(c.createdAt) = :year AND MONTH(c.createdAt) = :month")
    long countNewCustomersByMonth(@Param("year") int year, @Param("month") int month);
    
    // Lấy top học viên mới nhất
    @Query("SELECT c FROM Customer c ORDER BY c.createdAt DESC LIMIT :limit")
    List<Customer> findTopCustomersByCreatedAt(@Param("limit") int limit);
}