package com.tuition.management.controller.web;

import com.tuition.management.service.CustomerService;
import com.tuition.management.service.InvoiceService;
import com.tuition.management.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.time.LocalDate;

@Controller
public class DashboardController {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/")
    public String redirectToDashboard() {
        return "redirect:/dashboard";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        LocalDate now = LocalDate.now();
        LocalDate startOfMonth = now.withDayOfMonth(1);
        LocalDate endOfMonth = now.withDayOfMonth(now.lengthOfMonth());

        model.addAttribute("totalCustomers", customerService.getAllCustomers().size());
        model.addAttribute("pendingInvoices", invoiceService.getOverdueInvoices().size());
        model.addAttribute("monthlyRevenue", invoiceService.getTotalRevenue(startOfMonth, endOfMonth));
        model.addAttribute("recentPayments", paymentService.getPaymentsByDateRange(startOfMonth, endOfMonth));
        
        return "dashboard";
    }

    @GetMapping("/login")
    public String login() {
        return "auth/login";
    }
}