package com.tuition.management.repository;

import com.tuition.management.entity.Instructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InstructorRepository extends JpaRepository<Instructor, Long> {
    Optional<Instructor> findByEmail(String email);
    List<Instructor> findByStatus(String status);
    List<Instructor> findBySpecialty(String specialty);
}