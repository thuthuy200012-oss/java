package com.tuition.management.controller.web;

import com.tuition.management.entity.Payment;
import com.tuition.management.entity.Invoice;
import com.tuition.management.entity.User;
import com.tuition.management.entity.Customer;
import com.tuition.management.service.PaymentService;
import com.tuition.management.service.InvoiceService;
import com.tuition.management.service.UserService;
import com.tuition.management.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Objects;
import com.tuition.management.repository.InvoiceRepository;

import java.math.BigDecimal;
import java.time.LocalDate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/payments")
public class PaymentController {
private final InvoiceRepository invoiceRepository;

        public PaymentController(PaymentService paymentService,
                                UserService userService,
                                InvoiceRepository invoiceRepository) {
            this.paymentService = paymentService;
            this.userService = userService;
            this.invoiceRepository = invoiceRepository;
        }

    @Autowired
    private PaymentService paymentService;

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private UserService userService;

    @Autowired
    private CustomerService customerService;

    /**
     * Hiển thị danh sách thanh toán
     */
    @GetMapping
    public String listPayments(Model model) {
        List<Payment> payments = paymentService.getAllPayments();
        
        // Tính toán thống kê
        LocalDate now = LocalDate.now();
        LocalDate startOfMonth = now.withDayOfMonth(1);
        LocalDate endOfMonth = now.withDayOfMonth(now.lengthOfMonth());
        
        BigDecimal totalAmount = payments.stream()
                .filter(p -> "COMPLETED".equals(p.getStatus()))
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal monthlyAmount = payments.stream()
                .filter(p -> "COMPLETED".equals(p.getStatus()))
                .filter(p -> p.getPaymentDate() != null)
                .filter(p -> !p.getPaymentDate().isBefore(startOfMonth) && !p.getPaymentDate().isAfter(endOfMonth))
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        long todayCount = payments.stream()
                .filter(p -> p.getPaymentDate() != null && p.getPaymentDate().equals(now))
                .count();
        
        BigDecimal todayAmount = payments.stream()
                .filter(p -> p.getPaymentDate() != null && p.getPaymentDate().equals(now))
                .filter(p -> "COMPLETED".equals(p.getStatus()))
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        model.addAttribute("payments", payments);
        model.addAttribute("totalAmount", totalAmount);
        model.addAttribute("monthlyAmount", monthlyAmount);
        model.addAttribute("todayCount", todayCount);
        model.addAttribute("todayAmount", todayAmount);
        
        return "payments/list";
    }

    /**
     * Hiển thị form tạo thanh toán mới
     */
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        Payment payment = new Payment();
        payment.setPaymentDate(LocalDate.now());
        model.addAttribute("payment", payment);
        model.addAttribute("invoices", invoiceService.getAllInvoices().stream()
                .filter(i -> !"PAID".equals(i.getStatus()) && !"CANCELLED".equals(i.getStatus()))
                .collect(Collectors.toList()));
        return "payments/form";
    }

    /**
     * Hiển thị form tạo thanh toán cho hóa đơn cụ thể
     */
    @GetMapping("/new/invoice/{invoiceId}")
    public String showCreateFormForInvoice(@PathVariable Long invoiceId, Model model, RedirectAttributes redirectAttributes) {
        Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(invoiceId);
        if (invoiceOpt.isPresent()) {
            Invoice invoice = invoiceOpt.get();
            
            // Tính số tiền còn lại
            List<Payment> payments = paymentService.getPaymentsByInvoice(invoice);
            BigDecimal paidAmount = payments.stream()
                    .filter(p -> "COMPLETED".equals(p.getStatus()))
                    .map(Payment::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            BigDecimal remainingAmount = invoice.getTotalAmount().subtract(paidAmount);
            
            Payment payment = new Payment();
            payment.setInvoice(invoice);
            payment.setAmount(remainingAmount);
            payment.setPaymentDate(LocalDate.now());
            
            model.addAttribute("payment", payment);
            model.addAttribute("remainingAmount", remainingAmount);
            model.addAttribute("invoice", invoice);
            model.addAttribute("invoices", List.of(invoice));
            return "payments/form";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy hóa đơn");
            return "redirect:/payments";
        }
    }

    /**
     * Hiển thị form chỉnh sửa thanh toán
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Optional<Payment> paymentOpt = paymentService.getPaymentById(id);
        if (paymentOpt.isPresent()) {
            model.addAttribute("payment", paymentOpt.get());
            model.addAttribute("invoices", invoiceService.getAllInvoices());
            return "payments/form";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy thanh toán");
            return "redirect:/payments";
        }
    }

    /**
     * Lưu thanh toán (tạo mới hoặc cập nhật)
     */
   @PostMapping("/save")
public String savePayment(@ModelAttribute Payment payment, RedirectAttributes redirectAttributes) {
    try {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Optional<User> currentUser = userService.getUserByUsername(auth.getName());

        // 🔥 FIX QUAN TRỌNG NHẤT: LOAD INVOICE TỪ DB
        Long invoiceId = payment.getInvoice().getId();
        Invoice invoice = invoiceRepository
                .findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Invoice không tồn tại"));

        payment.setInvoice(invoice);

        if (payment.getId() == null) {
            // Tạo mới
            payment.setReceivedBy(currentUser.orElse(null));
            payment.setStatus("COMPLETED");
            paymentService.createPayment(payment);
            redirectAttributes.addFlashAttribute("success", "Ghi nhận thanh toán thành công!");
        } else {
            // Cập nhật
            paymentService.updatePayment(payment);
            redirectAttributes.addFlashAttribute("success", "Cập nhật thanh toán thành công!");
        }

        return "redirect:/payments";
    } catch (Exception e) {
        redirectAttributes.addFlashAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        return "redirect:/payments/new";
    }
}


    /**
     * Xem chi tiết thanh toán
     */
    @GetMapping("/view/{id}")
public String viewPayment(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
    try {
        Optional<Payment> paymentOpt = paymentService.getPaymentById(id);
        
        if (paymentOpt.isPresent()) {
            Payment payment = paymentOpt.get();
            
            // Tính toán thông tin liên quan nếu có invoice
            BigDecimal paidAmount = BigDecimal.ZERO;
            BigDecimal remainingAmount = BigDecimal.ZERO;
            
            if (payment.getInvoice() != null) {
                List<Payment> allPayments = paymentService.getPaymentsByInvoice(payment.getInvoice());
                paidAmount = allPayments.stream()
                        .filter(p -> p != null && "COMPLETED".equals(p.getStatus()))
                        .map(Payment::getAmount)
                        .filter(Objects::nonNull)
                        .reduce(BigDecimal.ZERO, BigDecimal::add);
                
                BigDecimal totalAmount = payment.getInvoice().getTotalAmount() != null ? 
                        payment.getInvoice().getTotalAmount() : BigDecimal.ZERO;
                remainingAmount = totalAmount.subtract(paidAmount);
            }
            
            model.addAttribute("payment", payment);
            model.addAttribute("paidAmount", paidAmount);
            model.addAttribute("remainingAmount", remainingAmount);
            
            return "payments/view";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy thanh toán với ID: " + id);
            return "redirect:/payments";
        }
    } catch (Exception e) {
        e.printStackTrace();
        redirectAttributes.addFlashAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        return "redirect:/payments";
    }
}

    /**
     * Xóa thanh toán
     */
    @GetMapping("/delete/{id}")
    public String deletePayment(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            paymentService.deletePayment(id);
            redirectAttributes.addFlashAttribute("success", "Xóa thanh toán thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Có lỗi khi xóa thanh toán: " + e.getMessage());
        }
        return "redirect:/payments";
    }

    /**
     * In phiếu thu
     */
   

    /**
     * Tìm kiếm thanh toán
     */
    @GetMapping("/search")
    public String searchPayments(@RequestParam String keyword,
                                  @RequestParam(required = false) String method,
                                  @RequestParam(required = false) String fromDate,
                                  @RequestParam(required = false) String toDate,
                                  Model model) {
        List<Payment> payments = paymentService.searchPayments(keyword, method, fromDate, toDate);
        model.addAttribute("payments", payments);
        model.addAttribute("keyword", keyword);
        model.addAttribute("searchMethod", method);
        model.addAttribute("fromDate", fromDate);
        model.addAttribute("toDate", toDate);
        
        // Tính lại thống kê cho kết quả tìm kiếm
        BigDecimal totalAmount = payments.stream()
                .filter(p -> "COMPLETED".equals(p.getStatus()))
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        model.addAttribute("totalAmount", totalAmount);
        
        return "payments/list";
    }

    /**
     * Lấy lịch sử thanh toán của học viên
     */
    @GetMapping("/customer/{customerId}")
    public String getPaymentsByCustomer(@PathVariable Long customerId, Model model) {
        List<Payment> payments = paymentService.getPaymentsByCustomerId(customerId);
        Optional<Customer> customerOpt = customerService.getCustomerById(customerId);
        
        if (customerOpt.isPresent()) {
            model.addAttribute("payments", payments);
            model.addAttribute("customer", customerOpt.get());
            model.addAttribute("totalAmount", payments.stream()
                    .map(Payment::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add));
            return "payments/customer-payments";
        }
        return "redirect:/payments";
    }

    /**
     * Xuất báo cáo thanh toán theo ngày
     */
    @GetMapping("/report/daily")
    public String dailyReport(@RequestParam(required = false) String date, Model model) {
        LocalDate reportDate = date != null ? LocalDate.parse(date) : LocalDate.now();
        
        List<Payment> payments = paymentService.getPaymentsByDate(reportDate);
        BigDecimal totalAmount = payments.stream()
                .map(Payment::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        model.addAttribute("payments", payments);
        model.addAttribute("reportDate", reportDate);
        model.addAttribute("totalAmount", totalAmount);
        model.addAttribute("paymentCount", payments.size());
        
        return "payments/daily-report";
    }

    /**
     * Hủy thanh toán
     */
    @PostMapping("/cancel/{id}")
    public String cancelPayment(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            paymentService.cancelPayment(id);
            redirectAttributes.addFlashAttribute("success", "Hủy thanh toán thành công!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Có lỗi khi hủy thanh toán: " + e.getMessage());
        }
        return "redirect:/payments";
    }
}