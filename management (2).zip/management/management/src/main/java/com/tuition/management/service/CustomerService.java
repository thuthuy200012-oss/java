package com.tuition.management.service;

import com.tuition.management.entity.Course;
import com.tuition.management.entity.Customer;
import com.tuition.management.repository.CourseRepository;
import com.tuition.management.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;
    
    @Autowired
    private CourseRepository courseRepository;  // Thêm CourseRepository

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Optional<Customer> getCustomerById(Long id) {
        return customerRepository.findById(id);
    }

    public Customer saveCustomer(Customer customer) {
        // Lấy khóa học cũ (nếu có) để cập nhật sau
        Long oldCourseId = null;
        if (customer.getId() != null) {
            Customer existing = customerRepository.findById(customer.getId()).orElse(null);
            if (existing != null) {
                oldCourseId = existing.getCourseId();
            }
        }
        
        // Tạo mã học viên nếu mới
        if (customer.getId() == null) {
            customer.setStudentCode(generateStudentCode());
            customer.setStatus("ACTIVE");
        }
        
        // Lưu học viên
        Customer saved = customerRepository.save(customer);
        
        // 🔥 Cập nhật số lượng cho khóa học MỚI
        if (customer.getCourseId() != null) {
            updateCourseStudentCount(customer.getCourseId(), 1);
            System.out.println("✅ Đã tăng số lượng khóa học ID: " + customer.getCourseId());
        }
        
        // 🔥 Giảm số lượng cho khóa học CŨ (nếu thay đổi khóa học)
        if (oldCourseId != null && !oldCourseId.equals(customer.getCourseId())) {
            updateCourseStudentCount(oldCourseId, -1);
            System.out.println("✅ Đã giảm số lượng khóa học ID: " + oldCourseId);
        }
        
        return saved;
    }

    public void deleteCustomer(Long id) {
        // Lấy thông tin học viên trước khi xóa để giảm số lượng khóa học
        Customer customer = customerRepository.findById(id).orElse(null);
        if (customer != null && customer.getCourseId() != null) {
            updateCourseStudentCount(customer.getCourseId(), -1);
            System.out.println("✅ Đã giảm số lượng khóa học ID: " + customer.getCourseId());
        }
        customerRepository.deleteById(id);
    }

    public List<Customer> searchCustomers(String keyword) {
        return customerRepository.search(keyword);
    }

    public List<Customer> getCustomersByStatus(String status) {
        return customerRepository.findByStatus(status);
    }

    private String generateStudentCode() {
        return "SV" + System.currentTimeMillis() + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
    }
    
    // Thêm method này
    public Optional<Customer> findById(Long id) {
        return customerRepository.findById(id);
    }
    
    // Cập nhật số lượng học viên của khóa học
    private void updateCourseStudentCount(Long courseId, int delta) {
        Optional<Course> courseOpt = courseRepository.findById(courseId);
        if (courseOpt.isPresent()) {
            Course course = courseOpt.get();
            int newCount = course.getCurrentStudents() + delta;
            if (newCount < 0) newCount = 0;
            if (newCount > course.getMaxStudents()) {
                throw new RuntimeException("Khóa học đã đủ số lượng học viên tối đa!");
            }
            course.setCurrentStudents(newCount);
            courseRepository.save(course);
            System.out.println("📊 Khóa " + course.getName() + ": " + newCount + "/" + course.getMaxStudents());
        }
    }
}