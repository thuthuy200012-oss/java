package com.tuition.management.service;

import com.tuition.management.entity.Customer;
import com.tuition.management.entity.Invoice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import jakarta.mail.internet.MimeMessage;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TemplateEngine templateEngine;

    @Value("${spring.mail.username}")
    private String fromEmail;

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    public void sendInvoiceReminder(Customer customer, Invoice invoice) {
        try {
            System.out.println("=== BẮT ĐẦU GỬI EMAIL ===");
            System.out.println("Đến: " + customer.getEmail());
            System.out.println("Hóa đơn: " + invoice.getInvoiceNumber());
            System.out.println("Số tiền còn lại: " + invoice.getRemainingAmount());
            System.out.println("Hạn thanh toán: " + invoice.getDueDate());

            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(customer.getEmail());
            helper.setSubject("[EduManager] NHẮC NHỞ THANH TOÁN HỌC PHÍ");

            String content = buildEmailContent(customer, invoice);
            helper.setText(content, true);

            mailSender.send(message);
            System.out.println("✅ GỬI THÀNH CÔNG!");

        } catch (Exception e) {
            System.err.println("❌ GỬI EMAIL THẤT BẠI: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String buildEmailContent(Customer customer, Invoice invoice) {
    Context context = new Context();
    
    // Tính số ngày còn lại
    long daysLeft = LocalDate.now().until(invoice.getDueDate()).getDays();
    
    // Lấy số tiền cần thanh toán từ AMOUNT (vì chưa có thanh toán)
    BigDecimal amountToPay = invoice.getAmount();
    if (amountToPay == null) {
        amountToPay = BigDecimal.ZERO;
    }
    
    // Log để kiểm tra
    System.out.println("=== SỐ TIỀN TRONG EMAIL ===");
    System.out.println("Amount: " + amountToPay);
    
    context.setVariable("customerName", customer.getFullName());
    context.setVariable("invoiceNumber", invoice.getInvoiceNumber());
    context.setVariable("dueDate", invoice.getDueDate().format(DATE_FORMATTER));
    context.setVariable("remainingAmount", amountToPay);  // 👈 THAY ĐỔI: dùng amount
    context.setVariable("invoiceId", invoice.getId());
    context.setVariable("daysLeft", daysLeft);
    context.setVariable("currentDate", LocalDate.now().format(DATE_FORMATTER));

    return templateEngine.process("email/invoice-reminder", context);
}
}