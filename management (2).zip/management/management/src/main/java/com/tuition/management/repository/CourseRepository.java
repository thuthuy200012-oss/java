package com.tuition.management.repository;

import com.tuition.management.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long> {
    
    List<Course> findByStatus(String status);
    
    List<Course> findByInstructor(String instructor);
    
    List<Course> findByStatusAndStartDateAfter(String status, LocalDate date);
    
    @Query("SELECT c FROM Course c WHERE c.status = 'ACTIVE' AND c.currentStudents < c.maxStudents")
    List<Course> findAvailableCourses();
    
    @Query("SELECT c FROM Course c WHERE c.name LIKE %:keyword% OR c.instructor LIKE %:keyword%")
    List<Course> searchCourses(@Param("keyword") String keyword);
    
    @Query("SELECT COUNT(c) FROM Course c WHERE c.status = 'ACTIVE'")
    Long countActiveCourses();
    
    @Query("SELECT AVG(c.currentStudents * 1.0 / c.maxStudents) FROM Course c WHERE c.status = 'ACTIVE'")
    Double getAverageOccupancyRate();
}