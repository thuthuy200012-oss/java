package com.tuition.management.controller.api;

import com.tuition.management.entity.Course;
import com.tuition.management.entity.Customer;
import com.tuition.management.service.CourseService;
import com.tuition.management.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/customers")
public class CustomerApi {

    @Autowired
    private CustomerService customerService;
    
    @Autowired
    private CourseService courseService;  // Thêm CourseService

    // Lấy tất cả khách hàng
    @GetMapping
    public List<Customer> getAllCustomers(){
        return customerService.getAllCustomers();
    }

    // Lấy khách hàng theo id - ĐÃ SỬA để trả về thêm thông tin khóa học
    @GetMapping("/{id}")
    public Map<String, Object> getCustomerById(@PathVariable Long id){
        Map<String, Object> result = new HashMap<>();
        
        Optional<Customer> customerOpt = customerService.getCustomerById(id);
        
        if (customerOpt.isPresent()) {
            Customer customer = customerOpt.get();
            result.put("id", customer.getId());
            result.put("fullName", customer.getFullName());
            result.put("studentCode", customer.getStudentCode());
            result.put("email", customer.getEmail());
            result.put("phone", customer.getPhone());
            result.put("courseId", customer.getCourseId());
            
            // Lấy thông tin khóa học nếu có
            if (customer.getCourseId() != null) {
                Optional<Course> courseOpt = courseService.findById(customer.getCourseId());
                if (courseOpt.isPresent()) {
                    Course course = courseOpt.get();
                    result.put("course", course.getName());
                    result.put("courseFee", course.getFee());
                    result.put("courseDuration", course.getDuration());
                    result.put("instructor", course.getInstructor());
                } else {
                    result.put("course", null);
                    result.put("courseFee", 0);
                }
            } else {
                result.put("course", null);
                result.put("courseFee", 0);
            }
        } else {
            result.put("error", "Không tìm thấy học viên");
        }
        
        return result;
    }

    // Tạo khách hàng
    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer){
        return customerService.saveCustomer(customer);
    }

    // Cập nhật khách hàng
    @PutMapping("/{id}")
    public Customer updateCustomer(@PathVariable Long id, @RequestBody Customer customer){
        customer.setId(id);
        return customerService.saveCustomer(customer);
    }

    // Xóa khách hàng
    @DeleteMapping("/{id}")
    public String deleteCustomer(@PathVariable Long id){
        customerService.deleteCustomer(id);
        return "Deleted successfully";
    }
}