package com.tuition.management.controller.web;

import com.tuition.management.entity.Invoice;
import com.tuition.management.entity.Course;
import com.tuition.management.entity.Customer;
import com.tuition.management.entity.Payment;
import com.tuition.management.entity.User;
import com.tuition.management.service.InvoiceService;
import com.tuition.management.service.CourseService;
import com.tuition.management.service.CustomerService;
import com.tuition.management.service.PaymentService;
import com.tuition.management.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Objects;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/invoices")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private CustomerService customerService;
    
   

    @Autowired
    private CourseService courseService;      // Thêm CourseServic
    @Autowired
    private PaymentService paymentService;

    @Autowired
    private UserService userService;

    /**
     * Hiển thị danh sách hóa đơn
     */
    @GetMapping
    public String listInvoices(Model model) {
        List<Invoice> invoices = invoiceService.getAllInvoices();
        
        // Tính toán thống kê
        long totalInvoices = invoices.size();
        long paidInvoices = invoices.stream()
                .filter(i -> "PAID".equals(i.getStatus()))
                .count();
        long pendingInvoices = invoices.stream()
                .filter(i -> "PENDING".equals(i.getStatus()))
                .count();
        long overdueInvoices = invoices.stream()
                .filter(i -> "OVERDUE".equals(i.getStatus()))
                .count();
        
        // Tính số tiền đã thanh toán cho mỗi hóa đơn
        for (Invoice invoice : invoices) {
            List<Payment> payments = paymentService.getPaymentsByInvoice(invoice);
            BigDecimal paidAmount = payments.stream()
                    .filter(p -> "COMPLETED".equals(p.getStatus()))
                    .map(Payment::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            invoice.setPaidAmount(paidAmount);
            
            // Tính số ngày còn lại đến hạn
            if (invoice.getDueDate() != null && "PENDING".equals(invoice.getStatus())) {
                long daysUntilDue = ChronoUnit.DAYS.between(LocalDate.now(), invoice.getDueDate());
                invoice.setDaysUntilDue((int) daysUntilDue);
            }
        }
        
        model.addAttribute("invoices", invoices);
        model.addAttribute("totalInvoices", totalInvoices);
        model.addAttribute("paidInvoices", paidInvoices);
        model.addAttribute("pendingInvoices", pendingInvoices);
        model.addAttribute("overdueInvoices", overdueInvoices);
        
        return "invoices/list";
    }

    /**
     * Hiển thị form tạo hóa đơn mới
     */
    @GetMapping("/new")
    public String showCreateForm(@RequestParam(required = false) Long customerId, Model model) {
        Invoice invoice = new Invoice();
        invoice.setIssueDate(LocalDate.now());
        invoice.setDueDate(LocalDate.now().plusDays(30));
        invoice.setStatus("PENDING");
        invoice.setPaidAmount(BigDecimal.ZERO);
        invoice.setInvoiceNumber("INV" + System.currentTimeMillis());
        
        if (customerId != null) {
            Customer customer = customerService.getCustomerById(customerId).orElse(null);
            if (customer != null) {
                invoice.setCustomer(customer);
                
                if (customer.getCourseId() != null) {
                    Course course = courseService.findById(customer.getCourseId()).orElse(null);
                    if (course != null) {
                        invoice.setCourse(course);
                        invoice.setAmount(BigDecimal.valueOf(course.getFee()));
                        invoice.setDescription("Học phí khóa " + course.getName());
                    }
                }
            }
        }
        
        model.addAttribute("invoice", invoice);
        model.addAttribute("customers", customerService.getAllCustomers());
        return "invoices/form";
    }


    
    
    

    /**
     * Hiển thị form chỉnh sửa hóa đơn
     */
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(id);
        if (invoiceOpt.isPresent()) {
            Invoice invoice = invoiceOpt.get();
            
            // Chỉ cho phép sửa hóa đơn ở trạng thái PENDING hoặc PARTIAL
            if (!"PENDING".equals(invoice.getStatus()) && !"PARTIAL".equals(invoice.getStatus())) {
                redirectAttributes.addFlashAttribute("error", 
                    "Không thể sửa hóa đơn đã " + getStatusText(invoice.getStatus()));
                return "redirect:/invoices";
            }
            
            model.addAttribute("invoice", invoice);
            model.addAttribute("customers", customerService.getAllCustomers());
            return "invoices/form";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy hóa đơn với ID: " + id);
            return "redirect:/invoices";
        }
    }

    /**
     * Lưu hóa đơn (tạo mới hoặc cập nhật)
     */
    @PostMapping("/save")
public String saveInvoice(@ModelAttribute Invoice invoice, 
                           @RequestParam(required = false) Long courseId,
                           RedirectAttributes redirectAttributes) {
    try {
        System.out.println("=== LƯU HÓA ĐƠN ===");
        System.out.println("courseId nhận từ request: " + courseId);
        
        // 🔥 QUAN TRỌNG: Xử lý courseId
        if (courseId != null && courseId > 0) {
            Course course = courseService.findById(courseId).orElse(null);
            if (course != null) {
                invoice.setCourse(course);
                System.out.println("Đã set course: " + course.getName());
                
                // Nếu amount chưa có, lấy từ khóa học
                if (invoice.getAmount() == null || invoice.getAmount().compareTo(BigDecimal.ZERO) == 0) {
                    invoice.setAmount(BigDecimal.valueOf(course.getFee()));
                }
            }
        }
        
        // Lấy thông tin người tạo
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Optional<User> currentUser = userService.getUserByUsername(auth.getName());
        
        // Tính tổng tiền
        BigDecimal total = invoice.getAmount() != null ? invoice.getAmount() : BigDecimal.ZERO;
        if (invoice.getDiscount() != null) {
            total = total.subtract(invoice.getDiscount());
        }
        if (invoice.getTax() != null && invoice.getTax().compareTo(BigDecimal.ZERO) > 0) {
            total = total.add(total.multiply(invoice.getTax().divide(BigDecimal.valueOf(100))));
        }
        invoice.setTotalAmount(total);
        invoice.setRemainingAmount(total.subtract(invoice.getPaidAmount() != null ? invoice.getPaidAmount() : BigDecimal.ZERO));
        
        // Tạo số hóa đơn nếu chưa có
        if (invoice.getInvoiceNumber() == null || invoice.getInvoiceNumber().isEmpty()) {
            invoice.setInvoiceNumber("INV" + System.currentTimeMillis());
        }
        
        if (invoice.getId() == null) {
            // Tạo mới
            invoice.setCreatedBy(currentUser.orElse(null));
            invoice.setStatus("PENDING");
            invoiceService.createInvoice(invoice);
            redirectAttributes.addFlashAttribute("success", "Tạo hóa đơn mới thành công!");
        } else {
            // Cập nhật
            Invoice existingInvoice = invoiceService.getInvoiceById(invoice.getId())
                    .orElseThrow(() -> new RuntimeException("Không tìm thấy hóa đơn"));
            
            invoice.setInvoiceNumber(existingInvoice.getInvoiceNumber());
            invoice.setCreatedBy(existingInvoice.getCreatedBy());
            invoice.setCreatedAt(existingInvoice.getCreatedAt());
            
            invoiceService.updateInvoice(invoice);
            redirectAttributes.addFlashAttribute("success", "Cập nhật hóa đơn thành công!");
        }
        
        System.out.println("Đã lưu hóa đơn, course_id: " + (invoice.getCourse() != null ? invoice.getCourse().getId() : "null"));
        
        return "redirect:/invoices";
    } catch (Exception e) {
        e.printStackTrace();
        redirectAttributes.addFlashAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        return "redirect:/invoices/new";
    }
}
    /**
     * Xem chi tiết hóa đơn
     */
   @GetMapping("/view/{id}")
public String viewInvoice(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
    try {
        Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(id);
        
        if (invoiceOpt.isPresent()) {
            Invoice invoice = invoiceOpt.get();
            
            // Lấy lịch sử thanh toán
            List<Payment> payments = paymentService.getPaymentsByInvoice(invoice);
            if (payments == null) {
                payments = new ArrayList<>();
            }
            
            // Tính tổng đã thanh toán
            BigDecimal paidAmount = payments.stream()
                    .filter(p -> p != null && "COMPLETED".equals(p.getStatus()))
                    .map(Payment::getAmount)
                    .filter(Objects::nonNull)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            // Tính số tiền còn lại
            BigDecimal totalAmount = invoice.getTotalAmount() != null ? invoice.getTotalAmount() : BigDecimal.ZERO;
            BigDecimal remainingAmount = totalAmount.subtract(paidAmount);
            
            // Tính số ngày đến hạn
            if (invoice.getDueDate() != null) {
                long daysUntilDue = ChronoUnit.DAYS.between(LocalDate.now(), invoice.getDueDate());
                invoice.setDaysUntilDue((int) daysUntilDue);
            }
            
            // Tính tiền thuế
            BigDecimal amount = invoice.getAmount() != null ? invoice.getAmount() : BigDecimal.ZERO;
            BigDecimal discount = invoice.getDiscount() != null ? invoice.getDiscount() : BigDecimal.ZERO;
            BigDecimal tax = invoice.getTax() != null ? invoice.getTax() : BigDecimal.ZERO;
            
            BigDecimal afterDiscount = amount.subtract(discount);
            BigDecimal taxAmount = afterDiscount.multiply(tax).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
            
            model.addAttribute("invoice", invoice);
            model.addAttribute("payments", payments);
            model.addAttribute("paidAmount", paidAmount);
            model.addAttribute("remainingAmount", remainingAmount);
            model.addAttribute("taxAmount", taxAmount);
            
            return "invoices/view";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy hóa đơn với ID: " + id);
            return "redirect:/invoices";
        }
    } catch (Exception e) {
        e.printStackTrace();
        redirectAttributes.addFlashAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        return "redirect:/invoices";
    }
}

    /**
     * In hóa đơn
     */
    @GetMapping("/print/{id}")
    public String printInvoice(@PathVariable Long id, 
                               @RequestParam(required = false) Boolean print,
                               Model model, 
                               RedirectAttributes redirectAttributes) {
        Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(id);
        if (invoiceOpt.isPresent()) {
            Invoice invoice = invoiceOpt.get();
            
            // Lấy lịch sử thanh toán
            List<Payment> payments = paymentService.getPaymentsByInvoice(invoice);
            List<Payment> completedPayments = payments.stream()
                    .filter(p -> "COMPLETED".equals(p.getStatus()))
                    .collect(Collectors.toList());
            
            // Tính các giá trị
            BigDecimal paidAmount = completedPayments.stream()
                    .map(Payment::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            BigDecimal remainingAmount = invoice.getTotalAmount().subtract(paidAmount);
            
            // Tính tiền thuế
            BigDecimal afterDiscount = invoice.getAmount().subtract(invoice.getDiscount() != null ? invoice.getDiscount() : BigDecimal.ZERO);
            BigDecimal taxAmount = afterDiscount.multiply(invoice.getTax() != null ? invoice.getTax() : BigDecimal.ZERO)
                    .divide(new BigDecimal("100"));
            
            model.addAttribute("invoice", invoice);
            model.addAttribute("payments", completedPayments);
            model.addAttribute("paidAmount", paidAmount);
            model.addAttribute("remainingAmount", remainingAmount);
            model.addAttribute("taxAmount", taxAmount);
            model.addAttribute("autoPrint", print != null && print);
            
            return "invoices/print";
        } else {
            redirectAttributes.addFlashAttribute("error", "Không tìm thấy hóa đơn với ID: " + id);
            return "redirect:/invoices";
        }
    }

    /**
     * Xóa hóa đơn
     */
    @GetMapping("/delete/{id}")
    public String deleteInvoice(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(id);
            if (invoiceOpt.isPresent()) {
                Invoice invoice = invoiceOpt.get();
                
                // Kiểm tra xem hóa đơn đã có thanh toán chưa
                List<Payment> payments = paymentService.getPaymentsByInvoice(invoice);
                if (!payments.isEmpty()) {
                    redirectAttributes.addFlashAttribute("error", 
                        "Không thể xóa hóa đơn đã có lịch sử thanh toán!");
                    return "redirect:/invoices";
                }
                
                // Chỉ cho phép xóa hóa đơn ở trạng thái PENDING hoặc CANCELLED
                if ("PAID".equals(invoice.getStatus())) {
                    redirectAttributes.addFlashAttribute("error", 
                        "Không thể xóa hóa đơn đã thanh toán!");
                    return "redirect:/invoices";
                }
                
                invoiceService.deleteInvoice(id);
                redirectAttributes.addFlashAttribute("success", "Xóa hóa đơn thành công!");
            } else {
                redirectAttributes.addFlashAttribute("error", "Không tìm thấy hóa đơn!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Có lỗi khi xóa hóa đơn: " + e.getMessage());
        }
        return "redirect:/invoices";
    }

    /**
     * Cập nhật trạng thái hóa đơn
     */
    @PostMapping("/update-status/{id}")
    @ResponseBody
    public String updateInvoiceStatus(@PathVariable Long id, @RequestParam String status) {
        try {
            Optional<Invoice> invoiceOpt = invoiceService.getInvoiceById(id);
            if (invoiceOpt.isPresent()) {
                Invoice invoice = invoiceOpt.get();
                invoice.setStatus(status);
                invoiceService.updateInvoice(invoice);
                return "success";
            }
            return "error: Invoice not found";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    /**
     * Tìm kiếm hóa đơn
     */
    @GetMapping("/search")
    public String searchInvoices(@RequestParam String keyword, 
                                  @RequestParam(required = false) String status,
                                  @RequestParam(required = false) Integer month,
                                  @RequestParam(required = false) Integer year,
                                  Model model) {
        List<Invoice> invoices = invoiceService.searchInvoices(keyword, status, month, year);
        
        // Tính toán thống kê tương tự list
        long totalInvoices = invoices.size();
        long paidInvoices = invoices.stream()
                .filter(i -> "PAID".equals(i.getStatus()))
                .count();
        long pendingInvoices = invoices.stream()
                .filter(i -> "PENDING".equals(i.getStatus()))
                .count();
        long overdueInvoices = invoices.stream()
                .filter(i -> "OVERDUE".equals(i.getStatus()))
                .count();
        
        // Tính số tiền đã thanh toán
        for (Invoice invoice : invoices) {
            List<Payment> payments = paymentService.getPaymentsByInvoice(invoice);
            BigDecimal paidAmount = payments.stream()
                    .filter(p -> "COMPLETED".equals(p.getStatus()))
                    .map(Payment::getAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            invoice.setPaidAmount(paidAmount);
        }
        
        model.addAttribute("invoices", invoices);
        model.addAttribute("totalInvoices", totalInvoices);
        model.addAttribute("paidInvoices", paidInvoices);
        model.addAttribute("pendingInvoices", pendingInvoices);
        model.addAttribute("overdueInvoices", overdueInvoices);
        model.addAttribute("keyword", keyword);
        model.addAttribute("searchStatus", status);
        model.addAttribute("searchMonth", month);
        model.addAttribute("searchYear", year);
        
        return "invoices/list";
    }

    /**
     * Lấy danh sách hóa đơn của học viên
     */
    @GetMapping("/customer/{customerId}")
    public String getInvoicesByCustomer(@PathVariable Long customerId, Model model) {
        Optional<Customer> customerOpt = customerService.getCustomerById(customerId);
        if (customerOpt.isPresent()) {
            Customer customer = customerOpt.get();
            List<Invoice> invoices = invoiceService.getInvoicesByCustomer(customer);
            
            model.addAttribute("invoices", invoices);
            model.addAttribute("customer", customer);
            model.addAttribute("totalAmount", invoices.stream()
                    .map(Invoice::getTotalAmount)
                    .reduce(BigDecimal.ZERO, BigDecimal::add));
            
            return "invoices/customer-invoices";
        }
        return "redirect:/invoices";
    }

    /**
     * Xuất báo cáo hóa đơn theo tháng
     */
    @GetMapping("/report/monthly")
    public String monthlyReport(@RequestParam(required = false) Integer month,
                                 @RequestParam(required = false) Integer year,
                                 Model model) {
        if (month == null) month = LocalDate.now().getMonthValue();
        if (year == null) year = LocalDate.now().getYear();
        
        LocalDate startDate = LocalDate.of(year, month, 1);
        LocalDate endDate = startDate.withDayOfMonth(startDate.lengthOfMonth());
        
        List<Invoice> invoices = invoiceService.getInvoicesByDateRange(startDate, endDate);
        
        BigDecimal totalRevenue = invoices.stream()
                .filter(i -> "PAID".equals(i.getStatus()))
                .map(Invoice::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal totalPending = invoices.stream()
                .filter(i -> "PENDING".equals(i.getStatus()))
                .map(Invoice::getTotalAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        model.addAttribute("invoices", invoices);
        model.addAttribute("month", month);
        model.addAttribute("year", year);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("totalPending", totalPending);
        model.addAttribute("invoiceCount", invoices.size());
        
        return "invoices/monthly-report";
    }

    /**
     * Helper method: Lấy text trạng thái
     */
    private String getStatusText(String status) {
        switch (status) {
            case "PAID": return "thanh toán";
            case "PENDING": return "chờ thanh toán";
            case "OVERDUE": return "quá hạn";
            case "PARTIAL": return "thanh toán một phần";
            case "CANCELLED": return "hủy";
            default: return status;
        }
    }
}