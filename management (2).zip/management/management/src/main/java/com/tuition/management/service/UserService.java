package com.tuition.management.service;

import com.tuition.management.entity.User;
import com.tuition.management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User saveUser(User user) {
        if (user.getId() == null) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        return userRepository.save(user);
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }

    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }

    /**
     * Tìm kiếm người dùng theo từ khóa
     * @param keyword Từ khóa tìm kiếm (tên, username, email)
     * @return Danh sách người dùng phù hợp
     */
    public List<User> searchUsers(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllUsers();
        }
        
        String searchKey = keyword.toLowerCase().trim();
        
        // Sử dụng Stream để filter
        return userRepository.findAll().stream()
                .filter(user -> 
                    user.getFullName().toLowerCase().contains(searchKey) ||
                    user.getUsername().toLowerCase().contains(searchKey) ||
                    (user.getEmail() != null && user.getEmail().toLowerCase().contains(searchKey)) ||
                    (user.getPhone() != null && user.getPhone().contains(searchKey))
                )
                .collect(Collectors.toList());
    }

    /**
     * Tìm kiếm người dùng nâng cao với nhiều tiêu chí
     * @param keyword Từ khóa
     * @param role Vai trò (ADMIN/STAFF)
     * @param enabled Trạng thái hoạt động
     * @return Danh sách người dùng
     */
    public List<User> searchUsersAdvanced(String keyword, String role, Boolean enabled) {
        List<User> users = getAllUsers();
        
        // Filter by keyword
        if (keyword != null && !keyword.trim().isEmpty()) {
            String searchKey = keyword.toLowerCase().trim();
            users = users.stream()
                    .filter(user -> 
                        user.getFullName().toLowerCase().contains(searchKey) ||
                        user.getUsername().toLowerCase().contains(searchKey) ||
                        (user.getEmail() != null && user.getEmail().toLowerCase().contains(searchKey))
                    )
                    .collect(Collectors.toList());
        }
        
        // Filter by role
        if (role != null && !role.isEmpty()) {
            users = users.stream()
                    .filter(user -> user.getRoles().stream()
                            .anyMatch(r -> r.getName().equals(role)))
                    .collect(Collectors.toList());
        }
        
        // Filter by status
        if (enabled != null) {
            users = users.stream()
                    .filter(user -> user.isEnabled() == enabled)
                    .collect(Collectors.toList());
        }
        
        return users;
    }

    /**
     * Đếm số lượng user theo vai trò
     */
    public long countByRole(String roleName) {
        return userRepository.findAll().stream()
                .filter(user -> user.getRoles().stream()
                        .anyMatch(role -> role.getName().equals(roleName)))
                .count();
    }

    /**
     * Lấy danh sách user đang hoạt động
     */
    public List<User> getActiveUsers() {
        return userRepository.findAll().stream()
                .filter(User::isEnabled)
                .collect(Collectors.toList());
    }

    /**
     * Lấy danh sách user bị khóa
     */
    public List<User> getInactiveUsers() {
        return userRepository.findAll().stream()
                .filter(user -> !user.isEnabled())
                .collect(Collectors.toList());
    }

    /**
     * Cập nhật trạng thái hoạt động
     */
    public User toggleUserStatus(Long id) {
        Optional<User> userOpt = getUserById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setEnabled(!user.isEnabled());
            return userRepository.save(user);
        }
        return null;
    }

    /**
     * Reset mật khẩu
     */
    public User resetPassword(Long id, String newPassword) {
        Optional<User> userOpt = getUserById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setPassword(passwordEncoder.encode(newPassword));
            return userRepository.save(user);
        }
        return null;
    }

    /**
     * Kiểm tra mật khẩu có đúng không
     */
    public boolean checkPassword(String rawPassword, String encodedPassword) {
        return passwordEncoder.matches(rawPassword, encodedPassword);
    }

    /**
     * Thay đổi mật khẩu
     */
    public boolean changePassword(Long id, String oldPassword, String newPassword) {
        Optional<User> userOpt = getUserById(id);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            if (passwordEncoder.matches(oldPassword, user.getPassword())) {
                user.setPassword(passwordEncoder.encode(newPassword));
                userRepository.save(user);
                return true;
            }
        }
        return false;
    }
}