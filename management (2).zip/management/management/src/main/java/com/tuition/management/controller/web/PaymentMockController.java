package com.tuition.management.controller.web;

import com.tuition.management.entity.Invoice;
import com.tuition.management.entity.Payment;
import com.tuition.management.service.InvoiceService;
import com.tuition.management.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Controller
@RequestMapping("/payments/mock")
public class PaymentMockController {

    @Autowired
    private InvoiceService invoiceService;

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/{invoiceId}")
    public String showMockPayment(@PathVariable Long invoiceId, Model model) {
        Invoice invoice = invoiceService.findById(invoiceId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy hóa đơn"));
        
        model.addAttribute("invoice", invoice);
        model.addAttribute("amount", invoice.getAmount());
        return "payments/mock";
    }

    @PostMapping("/process")
    public String processMockPayment(@RequestParam Long invoiceId,
                                      @RequestParam BigDecimal amount,
                                      @RequestParam String cardNumber,
                                      @RequestParam String cardHolder,
                                      @RequestParam String expiryDate,
                                      @RequestParam String cvv,
                                      RedirectAttributes redirectAttributes) {
        try {
            Invoice invoice = invoiceService.findById(invoiceId)
                    .orElseThrow(() -> new RuntimeException("Không tìm thấy hóa đơn"));

            if (!validateMockCard(cardNumber, expiryDate, cvv)) {
                throw new RuntimeException("Thông tin thẻ không hợp lệ");
            }

            // Tạo giao dịch thanh toán
            Payment payment = new Payment();
            payment.setPaymentNumber("PM" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
            payment.setInvoice(invoice);
            payment.setAmount(amount);
            payment.setPaymentDate(LocalDate.now());  // 👈 SỬA: dùng LocalDate
            payment.setPaymentMethod("MOCK_ONLINE");
            payment.setTransactionId("MOCK_" + System.currentTimeMillis());  // 👈 Dùng transactionId
            payment.setStatus("COMPLETED");
            payment.setNotes("Thanh toán online qua cổng MOCK");

            paymentService.save(payment);

            // Cập nhật hóa đơn
            BigDecimal paidAmount = invoice.getPaidAmount() != null ? invoice.getPaidAmount() : BigDecimal.ZERO;
            BigDecimal newPaid = paidAmount.add(amount);
            invoice.setPaidAmount(newPaid);
            
            BigDecimal remaining = invoice.getAmount().subtract(newPaid);
            if (remaining.compareTo(BigDecimal.ZERO) <= 0) {
                invoice.setStatus("PAID");
            }
            
            invoiceService.save(invoice);

            redirectAttributes.addFlashAttribute("success", 
                "Thanh toán thành công! Mã giao dịch: " + payment.getPaymentNumber());
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Thanh toán thất bại: " + e.getMessage());
        }
        return "redirect:/invoices/view/" + invoiceId;
    }

    private boolean validateMockCard(String cardNumber, String expiryDate, String cvv) {
        String cleanCard = cardNumber.replaceAll("\\s", "");
        if (cleanCard.length() != 16) return false;
        if (!expiryDate.matches("(0[1-9]|1[0-2])/\\d{2}")) return false;
        if (!cvv.matches("\\d{3}")) return false;
        return true;
    }
}