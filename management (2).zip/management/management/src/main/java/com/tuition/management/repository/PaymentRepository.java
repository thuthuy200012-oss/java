package com.tuition.management.repository;

import com.tuition.management.entity.Payment;
import com.tuition.management.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    
    List<Payment> findByInvoice(Invoice invoice);
    
    List<Payment> findByPaymentDateBetween(LocalDate startDate, LocalDate endDate);
    
    List<Payment> findByPaymentDate(LocalDate date);
    
    List<Payment> findByStatus(String status);
    
    @Query("SELECT SUM(p.amount) FROM Payment p WHERE " +
           "p.paymentDate BETWEEN :startDate AND :endDate AND p.status = 'COMPLETED'")
    Double getTotalPaymentAmount(@Param("startDate") LocalDate startDate, 
                                 @Param("endDate") LocalDate endDate);
    
    @Query("SELECT p FROM Payment p WHERE p.invoice.customer.id = :customerId")
    List<Payment> findByCustomerId(@Param("customerId") Long customerId);
    
    @Query("SELECT COUNT(p) FROM Payment p WHERE p.invoice = :invoice")
    long countByInvoice(@Param("invoice") Invoice invoice);
    
    @Query("SELECT p FROM Payment p ORDER BY p.paymentDate DESC, p.createdAt DESC")
    List<Payment> findTopByOrderByPaymentDateDesc(int limit);
    
    @Query("SELECT p FROM Payment p WHERE " +
           "LOWER(p.paymentNumber) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.invoice.customer.fullName) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.invoice.customer.studentCode) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(p.invoice.invoiceNumber) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Payment> search(@Param("keyword") String keyword);
    
    @Query("SELECT p FROM Payment p WHERE " +
           "p.paymentMethod = :method AND p.status = 'COMPLETED'")
    List<Payment> findByPaymentMethod(@Param("method") String method);
    
    @Query("SELECT YEAR(p.paymentDate) as year, MONTH(p.paymentDate) as month, " +
           "SUM(p.amount) as total FROM Payment p " +
           "WHERE p.status = 'COMPLETED' GROUP BY YEAR(p.paymentDate), MONTH(p.paymentDate)")
    List<Object[]> getMonthlyStats();
    
}