package com.tuition.management.config;

public class WebConfig {
    
}
