package com.tuition.management.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "payments")
@Data
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String paymentNumber;
    
    @ManyToOne
    @JoinColumn(name = "invoice_id", nullable = false)
    private Invoice invoice;
    
    @Column(nullable = false)
    private BigDecimal amount;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
@Column(nullable = false)


    private LocalDate paymentDate;
    
    private String paymentMethod; // CASH, BANK_TRANSFER, CREDIT_CARD
    
    private String transactionId;
    
    private String status; // COMPLETED, PENDING, FAILED, REFUNDED
    
    private String notes;
    
    @ManyToOne
    @JoinColumn(name = "received_by")
    private User receivedBy;
    
    private LocalDateTime createdAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (paymentDate == null) {
            paymentDate = LocalDate.now();
        }
    }
    

    
}